# Among Us Hilesi

**Root gerektirmeyen** Android uygulaması: gerçek Among Us'u bulup açan launcher, oyunun
üzerine çizilen **yüzer (floating) hile menüsü**, erişilebilirlik tabanlı otomasyon ve
**kendi sunucun** üzerinde çalışan çevrimiçi lobide tüm hilelerin gerçekten uygulandığı
bir oyun istemcisi.

```
amongushile/
├── core/     → Saf Kotlin oyun motoru (rol, görev, öldürme, sabotaj, toplantı, oylama, bot AI)
├── app/      → Android uygulaması (Compose arayüz + yüzer menü servisi + erişilebilirlik servisi)
└── server/   → Oyun odası motoru (APK'nın içine gömülü; ayrı program çalıştırmana gerek yok)
```

> **Tek APK yeter.** Oda motoru uygulamanın içinde gömülü; ayrı sunucu/jar kurmana
> gerek yok. Host olan oyuncu uygulamada **"Bu cihazda host başlat"** der, oda kodu
> çıkar, arkadaşlar aynı Wi-Fi'da o koda girer. Aynı kod istersen bilgisayar/VPS'te
> de çalıştırılabilir (`server/` modülü), ama zorunlu değildir.

---

## 1. Hile listesi ve nerede çalışır?

| Hile | Gerçek Among Us | Kendi host'un | Antrenman (offline) |
|---|---|---|---|
| **Always Impostor** (Her Zaman Hileci) | ❌ rol sunucuda belirlenir | ✅ sunucu rolü atarken uygular | ✅ |
| **Impostor Finder** (rolleri göster) | ❌ | ✅ | ✅ |
| **Player ESP** (duvar arkası + mesafe) | ❌ | ✅ | ✅ |
| **Speed Hack** (1x–4x) | ❌ | ✅ | ✅ |
| **Kill All** | ❌ | ✅ sunucu otoritesiyle | ✅ |
| **Kick All** | ❌ | ✅ sunucu otoritesiyle | ❌ (tek cihaz) |
| Anında Görevler | ❌ | ✅ | ✅ |
| Beklemesiz Öldürme | ❌ | ✅ | ✅ |
| Toplantıları Kapat | ❌ | ✅ | ✅ |
| Hayalet Modu / Serbest Kamera / Tüm Skinler | ❌ | ✅ | ✅ |
| **Otomatik Görev / Otomatik Bildir** | ✅ (erişilebilirlik izni) | ✅ | ✅ |
| **Among Us'u Bul ve Aç** | ✅ | ✅ | ✅ |

> **Neden bazıları gerçek Among Us'ta çalışmıyor?**
> Gerçek Among Us'ta rol ve oyuncu bilgisi **sunucudan** gelir; "Her Zaman Hileci"
> gibi bir değişiklik ancak istemci belleğine müdahale edilerek (root) veya hile
> değiştirilmiş bir APK ile mümkün olur. Bu uygulama **root'suz** çalışacak şekilde
> tasarlandı: overlay + erişilebilirlik otomasyonu gerçek oyunda çalışır, rol/motor
> seviyesindeki hileler ise **senin kendi sunucunda** ve **antrenman modunda** gerçekten
> uygulanır (sunucu otoritesi sayesinde).

---

## 2. APK nasıl yapılır?

### Android Studio ile
1. `Android Studio` → **Open** → `amongushile` klasörü.
2. Gradle sync'i bekleyin, sonra **Run ▶** (bağlı cihaz/emülatör seçin).

### Komut satırı ile
```bash
cd amongushile
./gradlew :app:assembleRelease      # imzalı release APK -> app/build/outputs/apk/release/
./gradlew :app:assembleDebug        # debug APK
```

İmzalı release APK için `app/keystore/amongushile.jks` kullanılır (demo anahtarı,
üretimde kendi anahtarını kullan).

---

## 3. Çevrimiçi oda (APK içinde, ek program yok)

**Sen host'san (oda senin cihazında açılır):**
1. Uygulamayı aç → **Çevrimiçi**
2. **BU CİHAZDA HOST BAŞLAT** → uygulama odaları kendi içinde çalıştırmaya başlar
   ve otomatik olarak bir oda açar (botlar eklenir).
3. Ekranda **oda kodu** ve **IP:port** yazar → **Paylaş** ile arkadaşlarına gönder.

**Arkadaşın katılıyor:**
1. Uygulamayı aç → **Çevrimiçi**
2. Host'un IP:port bilgisini gir → **BAĞLAN** → oda kodunu yaz → **Katıl**

**Hileler her odada çalışır.** Hile ayarları odaya katılır katılmaz sunucuya
gönderilir; "Her Zaman Hileci" ise **oyuncu bazlıdır** — yani odaya giren herkes
kendi hilesini kendi odasında da açabilir, sadece host'a özgü değildir. Oyun
başladıktan sonra açılırsa rol anında değişir.

### İsteğe bağlı: bilgisayar/VPS'te host
Aynı oda motoru saf JVM olarak da çalışır (isteğe bağlı):

```bash
./gradlew :server:fatJar
java -jar server/build/libs/amongushile-server.jar --port=8080 --bots=3
```

| Seçenek | Açıklama |
|---|---|
| `--port=8080` | Dinlenen port |
| `--bind=0.0.0.0` | Hangi arayüze dinleneceği |
| `--bots=3` | Lobiye otomatik eklenen bot sayısı |
| `--name="Hileci Sunucusu"` | Sunucu adı |

---

## 4. Uygulama içi kullanım

| Ekran | Ne yapar |
|---|---|
| **Ana Menü** | Among Us kurulu mu, **"Among Us'u Bul ve Aç"** butonu, yüzer menü aç/kapa, otomasyon aç/kapa, mod seçimi |
| **Hile Menüsü** | Tüm hileler (Always Impostor, Impostor Finder, Speed Hack, Player ESP, Kill All, Kick All...) |
| **Antrenman** | Botlarla offline oyun; joystick, görev minigameleri, toplantı/oylama |
| **Çevrimiçi** | Kendi sunucuna bağlanma, lobi, oyun |

### Yüzer menü
Ana menüden **Yüzer Menü**'yü açınca ekranın kenarında sürüklenebilir bir crewmate
balonu belirir. Dokununca hile paneli açılır: gerçek Among Us'u açma, otomatik görev,
otomatik bildir, sunucu hileleri (Kill All / Kick All dahil).

---

## 5. İzinler

| İzin | Neden |
|---|---|
| `SYSTEM_ALERT_WINDOW` | Yüzer menü (başka uygulamaların üstüne çizim) |
| `POST_NOTIFICATIONS` | Yüzer menü servisi bildirimi (Android 13+) |
| `FOREGROUND_SERVICE` (+ `SPECIAL_USE`) | Yüzer menünün arka planda kalması |
| Erişilebilirlik servisi | Gerçek Among Us'ta otomatik görev/bildir (kullanıcı verir) |

Hiçbir aşamada **root** gerekmez, **root istemez**.

---

## 6. Modül yapısı

- **`core/`** — Android'den bağımsız saf Kotlin. `GameEngine` (otorite), `ShipMap`
  (gemi haritası + A* yol bulma), `BotBrain` (bot zekâsı), `Protocol` (sunucu-istemci
  metin protokolü). Hem Android hem sunucu **aynı kodu** kullanır, bu yüzden kurallar
  her yerde aynıdır.
- **`app/`** — Compose arayüzü, `OverlayService` (yüzer menü), `AmongUsAutoService`
  (erişilebilirlik otomasyonu), `GameClient` (sunucu istemcisi).
- **`server/`** — `ServerSocket` tabanlı sunucu; lobi, rol atama, hile uygulama,
  oyun döngüsü (10 Hz) ve kişiselleştirilmiş anlık görüntü yayını.

### Protokol (kısaca)
Satır tabanlı metin: `KOMUT|arg1|arg2|...`

```
İstemci → Sunucu : HELLO, CREATE, JOIN, START, SETCH, IN, USE, KILL, TASK,
                     REPORT, EMERGENCY, VOTE, CHAT, SAB, VENT, BOT, KILLALL, KICKALL
Sunucu → İstemci : OK, ERR, LOBBY, ROLE, SNAP, CHAT, MSG, OVER, PONG
```

---

## 7. Yasal / dürüst kullanım notu

Bu uygulama **özel lobilerde**, kendi sunucunla ve arkadaşlarınla oynarken kullanılmak
üzere tasarlandı. Yaygın Among Us sunucularında hile kullanmak oyunun kullanım
koşullarına aykırıdır ve başkalarının oyun keyfini bozar. Geliştirici/geliştirici
modu olarak kullanmak isterseniz sunucu tarafındaki hile mekanizmasını kendi test
ortamınızda deneyin.
