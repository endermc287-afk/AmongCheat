package com.amongushile.server

import com.amongushile.core.GameConfig
import com.amongushile.core.GameEngine
import com.amongushile.core.Input
import com.amongushile.core.Player
import com.amongushile.core.Protocol
import com.amongushile.core.SabotageType
import com.amongushile.core.Body
import com.amongushile.core.Winner
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Bağlantı başına oyuncu bağlantısı.
 */
class ClientConn(
    val socket: Socket,
    val reader: BufferedReader,
    val writer: PrintWriter,
) {
    var playerId: Int = -1
    var room: Room? = null
    var name: String = "Oyuncu"
    var colorIndex: Int = 0
    var connected: Boolean = true
    var input: Input = Input.NONE
    private val sendLock = Any()

    fun send(line: String) {
        synchronized(sendLock) {
            try {
                writer.println(line)
                writer.flush()
            } catch (e: Exception) {
                connected = false
            }
        }
    }
}

/**
 * Bir oda (lobi). Oyun motoru bu odanın içinde yaşar.
 */
class Room(val code: String, val botCount: Int) {
    val engine = GameEngine(GameConfig(playerCount = 8, taskCount = 5))
    val clients = ConcurrentHashMap<Int, ClientConn>()
    var hostId: Int = -1
    var chatCursor: Int = 0
    var started: Boolean = false

    fun broadcast(line: String) {
        clients.values.forEach { it.send(line) }
    }

    fun broadcastLobby() {
        broadcast(Protocol.encodeLobby(code, hostId, engine.players))
    }

    fun addBot(name: String): Player = engine.addPlayer(name, engine.players.size, isBot = true)
}

/**
 * Among Us Hilesi - kendi sunucun.
 *
 * Hem ayrı bir program olarak (java -jar amongushile-server.jar) hem de Android
 * uygulamasının içinde (telefonun kendisi host olur) çalışabilir.
 *
 * Oyunu "yetkili" olarak bu sunucu yönetir; Always Impostor, Impostor Finder,
 * Speed Hack, Player ESP, Kill All ve Kick All hileleri burada gerçekten uygulanır.
 */
class HileServer(
    val port: Int = 8080,
    val bind: String = "0.0.0.0",
    val botCount: Int = 3,
    val serverName: String = "Hileci Sunucusu",
) {
    private val rooms = ConcurrentHashMap<String, Room>()
    private val roomSeq = AtomicInteger(0)
    private var serverSocket: ServerSocket? = null
    private var tickThread: Thread? = null
    @Volatile
    var running: Boolean = false
        private set

    /** Dinlenen gerçek port (0 verildiyse atanır). */
    @Volatile
    var actualPort: Int = port
        private set

    fun start(): Boolean {
        if (running) return true
        return try {
            val s = ServerSocket(port, 50, InetAddress.getByName(bind))
            serverSocket = s
            actualPort = s.localPort
            running = true
            tickThread = Thread { tickLoop() }.apply {
                isDaemon = true
                name = "hilesi-tick"
                start()
            }
            Thread {
                while (running) {
                    val socket = try {
                        s.accept()
                    } catch (e: Exception) {
                        if (running) continue else break
                    }
                    Thread { handleClient(socket) }.apply {
                        isDaemon = true
                        name = "hilesi-client"
                        start()
                    }
                }
            }.apply {
                isDaemon = true
                name = "hilesi-accept"
                start()
            }
            true
        } catch (e: Exception) {
            running = false
            System.err.println("Sunucu hatasi: ${e.javaClass.simpleName}: ${e.message}")
            e.printStackTrace()
            false
        }
    }

    fun stop() {
        running = false
        try {
            serverSocket?.close()
        } catch (ignored: Exception) {
        }
        serverSocket = null
    }

    // ------------------------------------------------------------ oyun döngüsü

    private fun tickLoop() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            var dt = (now - last) / 1_000_000_000f
            last = now
            if (dt > 0.5f) dt = 0.5f

            for (room in rooms.values) {
                try {
                    tickRoom(room, dt)
                } catch (e: Exception) {
                    System.err.println("Oda hatası (${room.code}): ${e.message}")
                }
            }
            try {
                Thread.sleep(40)
            } catch (e: InterruptedException) {
                return
            }
        }
    }

    private fun tickRoom(room: Room, dt: Float) {
        if (room.engine.phase == com.amongushile.core.Phase.LOBBY) return

        val inputs = HashMap<Int, Input>()
        for ((pid, c) in room.clients) {
            inputs[pid] = c.input
            c.input = c.input.copy(
                use = false, kill = false, taskDone = false,
                report = false, emergency = false,
            )
        }
        room.engine.update(dt, inputs)

        // Toplantı sohbeti (botlar dahil) yeni mesajları yayınla
        val m = room.engine.meeting
        if (m != null) {
            while (room.chatCursor < m.chat.size) {
                val msg = m.chat[room.chatCursor]
                room.chatCursor++
                room.broadcast(Protocol.encode(Protocol.CHAT, msg.playerId, msg.name, Protocol.escape(msg.text)))
            }
        } else {
            room.chatCursor = 0
        }

        if (room.engine.winner != null) {
            room.broadcast(Protocol.encode(Protocol.OVER, room.engine.winner!!.name))
            return
        }

        // Her istemciye kişiselleştirilmiş anlık görüntü
        for ((pid, c) in room.clients) {
            room.engine.localPlayerId = pid
            val snap = room.engine.snapshot()
            c.send(Protocol.SNAP + "|" + Protocol.encodeSnapshot(snap))
        }
        room.engine.localPlayerId = -1
    }

    // ------------------------------------------------------------ istemci

    private fun handleClient(socket: Socket) {
        val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
        val writer = PrintWriter(socket.getOutputStream(), true, Charsets.UTF_8)
        val conn = ClientConn(socket, reader, writer)
        conn.send(Protocol.encode(Protocol.OK, "$serverName hazır"))

        try {
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isBlank()) continue
                handleMessage(conn, line)
            }
        } catch (e: Exception) {
            // bağlantı kapandı
        } finally {
            cleanup(conn)
            try {
                socket.close()
            } catch (ignored: Exception) {
            }
        }
    }

    private fun cleanup(conn: ClientConn) {
        val room = conn.room ?: return
        room.clients.remove(conn.playerId)
        room.engine.removePlayer(conn.playerId)
        room.engine.alwaysImpostorIds.remove(conn.playerId)
        if (room.hostId == conn.playerId) {
            room.hostId = room.clients.keys.firstOrNull() ?: -1
        }
        room.broadcast(Protocol.encode(Protocol.MSG, "${conn.name} ayrıldı"))
        room.broadcastLobby()
    }

    private fun handleMessage(conn: ClientConn, line: String) {
        val f = Protocol.split(line)
        val cmd = f.getOrNull(0) ?: return
        val room = conn.room
        val engine = room?.engine

        when (cmd) {
            Protocol.HELLO -> {
                conn.name = com.amongushile.core.Colors.sanitizeName(f.getOrNull(1) ?: "Oyuncu")
                conn.colorIndex = f.getOrNull(2)?.toIntOrNull() ?: 0
                conn.send(Protocol.encode(Protocol.OK, "Hoş geldin ${conn.name}"))
            }

            Protocol.CREATE -> {
                val code = (f.getOrNull(1)?.uppercase()?.takeIf { it.length >= 3 }) ?: randomRoomCode()
                val r = rooms.getOrPut(code) { Room(code, botCount) }
                joinRoom(conn, r)
            }

            Protocol.JOIN -> {
                val code = f.getOrNull(1)?.uppercase() ?: return
                val r = rooms[code]
                if (r == null) {
                    conn.send(Protocol.encode(Protocol.ERR, "Oda bulunamadı: $code"))
                    return
                }
                joinRoom(conn, r)
            }

            Protocol.BOT -> {
                if (room == null) return
                val n = f.getOrNull(1)?.toIntOrNull() ?: 1
                repeat(n.coerceIn(0, 8)) { room.addBot("Bot ${room.engine.players.size}") }
                room.broadcastLobby()
            }

            Protocol.START -> {
                if (room == null || engine == null) return
                if (room.hostId != conn.playerId && room.hostId != -1) {
                    conn.send(Protocol.encode(Protocol.ERR, "Sadece oda sahibi başlatabilir"))
                    return
                }
                if (room.engine.players.size < 2) {
                    conn.send(Protocol.encode(Protocol.ERR, "En az 2 oyuncu gerekli"))
                    return
                }
                room.engine.start()
                room.started = true
                room.broadcast(Protocol.encode(Protocol.MSG, "Oyun başladı!"))
                room.broadcastLobby()
            }

            Protocol.SETCH -> {
                if (room == null || engine == null) return
                val key = f.getOrNull(1) ?: return
                val value = f.getOrNull(2) ?: "1"
                applyCheat(room, conn, key, value)
            }

            Protocol.INPUT -> {
                val dx = f.getOrNull(1)?.toFloatOrNull() ?: 0f
                val dy = f.getOrNull(2)?.toFloatOrNull() ?: 0f
                conn.input = conn.input.copy(moveX = dx, moveY = dy)
            }

            Protocol.USE -> engine?.handleUse(conn.playerId)
            Protocol.KILL -> engine?.tryKill(conn.playerId, f.getOrNull(1)?.toIntOrNull() ?: -1)
            Protocol.TASK -> engine?.completeTask(conn.playerId, f.getOrNull(1)?.toIntOrNull() ?: -1)
            Protocol.REPORT -> engine?.tryReportNearBody(conn.playerId)
            Protocol.EMERGENCY -> engine?.callEmergency(conn.playerId)
            Protocol.VOTE -> engine?.castVote(conn.playerId, f.getOrNull(1)?.toIntOrNull() ?: -1)
            Protocol.CHAT -> engine?.sendChat(conn.playerId, f.drop(1).joinToString("|"))
            Protocol.SAB -> {
                val type = SabotageType.entries.firstOrNull { it.name == f.getOrNull(1) }
                if (type != null) engine?.triggerSabotage(conn.playerId, type)
            }
            Protocol.VENT -> engine?.useVent(conn.playerId, f.getOrNull(1)?.toIntOrNull() ?: -1)
            Protocol.KILLALL -> room?.let { killAll(it, conn) }
            Protocol.KICKALL -> room?.let { kickAll(it, conn) }
            Protocol.PING -> conn.send(Protocol.PONG)
            else -> conn.send(Protocol.encode(Protocol.ERR, "Bilinmeyen komut: $cmd"))
        }
    }

    private fun joinRoom(conn: ClientConn, room: Room) {
        conn.room = room
        val player = room.engine.addPlayer(conn.name, conn.colorIndex, isBot = false)
        conn.playerId = player.id
        room.clients[player.id] = conn
        if (room.hostId == -1) room.hostId = player.id
        room.broadcast(Protocol.encode(Protocol.MSG, "${player.name} lobiye katıldı"))
        room.broadcastLobby()
        conn.send(Protocol.encode(Protocol.OK, "Odaya katıldın: ${room.code}"))
        conn.send(Protocol.encode(Protocol.ROLE, "CREWMATE", ""))
    }

    /** Hile uygulaması: sunucu yetkili olduğu için gerçekten etkili. */
    private fun applyCheat(room: Room, conn: ClientConn, key: String, value: String) {
        val engine = room.engine
        val on = value == "1" || value == "true"
        when (key) {
            "alwaysImpostor" -> {
                if (on) {
                    engine.alwaysImpostorIds.add(conn.playerId)
                    // Oyun başladıysa rolü anında değiştir
                    if (engine.phase == com.amongushile.core.Phase.PLAYING) {
                        engine.forceImpostor(conn.playerId)
                        room.broadcast(
                            Protocol.encode(
                                Protocol.MSG,
                                "${engine.playerById(conn.playerId)?.name ?: "Oyuncu"} artık HİLECİ!",
                            )
                        )
                    }
                } else {
                    engine.alwaysImpostorIds.remove(conn.playerId)
                    if (engine.phase == com.amongushile.core.Phase.PLAYING) {
                        engine.forceCrewmate(conn.playerId)
                    }
                }
            }
            "noMeetings" -> engine.cheats = engine.cheats.copy(noMeetings = on)
            "instantTasks" -> engine.cheats = engine.cheats.copy(instantTasks = on)
            "skipKillCooldown" -> engine.cheats = engine.cheats.copy(skipKillCooldown = on)
            "freeCamera" -> engine.cheats = engine.cheats.copy(freeCamera = on)
            "unlockSkins" -> engine.cheats = engine.cheats.copy(unlockSkins = on)
            "ghostMode" -> engine.cheats = engine.cheats.copy(ghostMode = on)
            "revealRoles" -> engine.cheats = engine.cheats.copy(revealRoles = on)
            "noVoteCooldown" -> engine.cheats = engine.cheats.copy(noVoteCooldown = on)
            "playerEsp" -> engine.cheats = engine.cheats.copy(playerEsp = on)
            "speed" -> {
                val mult = value.toFloatOrNull() ?: 1f
                engine.cheats = engine.cheats.copy(walkSpeedMultiplier = mult.coerceIn(0.5f, 4f))
            }
            "impostorCount" -> {
                val n = value.toIntOrNull() ?: 1
                engine.cheats = engine.cheats.copy(impostorCount = n.coerceIn(1, 4))
            }
            "killAll" -> if (on) killAll(room, conn)
            "kickAll" -> if (on) kickAll(room, conn)
            else -> return
        }
        room.broadcast(Protocol.encode(Protocol.MSG, "Hile güncellendi: $key=$value"))
    }

    private fun killAll(room: Room, conn: ClientConn) {
        val engine = room.engine
        for (p in engine.aliveCrew()) {
            p.alive = false
            engine.bodies.add(Body(System.identityHashCode(p) % 100000, p.x, p.y, p.colorIndex))
        }
        engine.finishGame(Winner.IMPOSTORS)
        room.broadcast(Protocol.encode(Protocol.MSG, "KILL ALL: bütün mürettebatlar öldürüldü"))
    }

    private fun kickAll(room: Room, conn: ClientConn) {
        val victims = room.clients.values.filter { it.playerId != conn.playerId }
        for (v in victims) {
            v.send(Protocol.encode(Protocol.ERR, "Oda sahibi tarafından atıldın"))
            try {
                v.socket.close()
            } catch (ignored: Exception) {
            }
        }
        room.broadcast(Protocol.encode(Protocol.MSG, "KICK ALL: lobideki diğer oyuncular atıldı"))
    }

    private fun randomRoomCode(): String {
        val letters = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        var code: String
        do {
            code = (1..4).map { letters.random() }.joinToString("")
        } while (rooms.containsKey(code))
        return code
    }

    companion object {
        /** Cihazın yerel ağ IP'si (telefon/bilgisayar). */
        fun localIp(): String = try {
            java.net.InetAddress.getLocalHost().hostAddress
        } catch (e: Exception) {
            "127.0.0.1"
        }
    }
}

/** JVM giriş noktası: java -jar amongushile-server.jar */
fun main(args: Array<String>) {
    var port = 8080
    var bind = "0.0.0.0"
    var bots = 3
    var name = "Hileci Sunucusu"
    for (a in args) {
        when {
            a.startsWith("--port=") -> port = a.removePrefix("--port=").toIntOrNull() ?: port
            a.startsWith("--bind=") -> bind = a.removePrefix("--bind=")
            a.startsWith("--bots=") -> bots = a.removePrefix("--bots=").toIntOrNull() ?: 3
            a.startsWith("--name=") -> name = a.removePrefix("--name=")
        }
    }

    val server = HileServer(port = port, bind = bind, botCount = bots, serverName = name)
    if (!server.start()) {
        println("Sunucu başlatılamadı (port $port meşgul olabilir).")
        return
    }

    println("╔══════════════════════════════════════════════╗")
    println("║        AMONG US HİLESİ - KENDİ SUNUCUN        ║")
    println("╚══════════════════════════════════════════════╝")
    println("Sunucu adı : $name")
    println("Port       : ${server.actualPort}")
    println("Bot sayısı : $bots")
    println("Yerel IP   : ${HileServer.localIp()}")
    println("Telefondan: Uygulamada adres olarak ${HileServer.localIp()}:${server.actualPort} yaz.")
    println("Durdurma   : Ctrl+C")
    println()

    Runtime.getRuntime().addShutdownHook(Thread { server.stop() })
    Thread.currentThread().join()
}
