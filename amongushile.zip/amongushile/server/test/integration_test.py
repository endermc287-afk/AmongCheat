#!/usr/bin/env python3
"""
Among Us Hilesi - sunucu entegrasyon testi (saf Python, ek bağımlılık yok).

Kullanım:
    python3 server/test/integration_test.py --port 8099

Test edilenler:
  1) Oda kurma / katılma / lobi listesi
  2) Hile sunucuya gider mi? (Always Impostor dahil)
  3) Başkasının odasında da hile çalışıyor mu?
  4) Oyun başlıyor mu, anlık görüntü (SNAP) geliyor mu?
  5) Kill All / Kick All komutları
"""

import argparse
import socket
import sys
import time

HOST = "127.0.0.1"


class Client:
    def __init__(self, name, port, color=0):
        self.name = name
        self.sock = socket.create_connection((HOST, port), timeout=10)
        self.sock.settimeout(0.4)
        self.buf = b""
        self.lines = []
        self.send(f"HELLO|{name}|{color}")

    def send(self, line):
        self.sock.sendall((line + "\n").encode("utf-8"))

    def _pump(self):
        try:
            data = self.sock.recv(4096)
            if not data:
                return False
            self.buf += data
            while b"\n" in self.buf:
                raw, self.buf = self.buf.split(b"\n", 1)
                line = raw.decode("utf-8", "ignore").strip()
                if line:
                    self.lines.append(line)
        except socket.timeout:
            pass
        except OSError:
            return False
        return True

    def wait(self, prefix, timeout=6.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            for line in list(self.lines):
                if line.startswith(prefix + "|") or line == prefix:
                    return line
            if not self._pump():
                time.sleep(0.05)
        return None

    def collect(self, prefix, seconds=1.5):
        deadline = time.time() + seconds
        out = []
        while time.time() < deadline:
            out += [l for l in self.lines if l.startswith(prefix + "|")]
            self._pump()
        return out

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass


def parse_snapshot(payload):
    f = payload.split("|")
    return {
        "phase": f[0],
        "localPlayerId": int(f[1]),
        "tasksDone": int(f[2]),
        "taskSlots": int(f[3]),
        "winner": f[9],
        "players": [
            {
                "id": int(p[0]),
                "color": int(p[1]),
                "role": p[2],
                "alive": p[5] == "1",
                "bot": p[6] == "1",
            }
            for p in f[12].split(";")
            if p
        ],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8099)
    args = ap.parse_args()

    failures = []

    def check(label, cond, detail=""):
        if cond:
            print(f"  ✓ {label}")
        else:
            print(f"  ✗ {label} {detail}")
            failures.append(label)

    print("1) Bağlantı ve lobi")
    host = Client("Host", args.port, 0)
    check("host 'OK' aldı", host.wait("OK") is not None)
    host.send("CREATE|")
    lobby = host.wait("LOBBY")
    check("oda kuruldu (LOBBY geldi)", lobby is not None)
    room_code = lobby.split("|")[1] if lobby else ""
    check("oda kodu üretildi", len(room_code) == 4, room_code)

    print("2) İkinci oyuncu katılıyor")
    guest = Client("Misafir", args.port, 3)
    guest.wait("OK")
    guest.send(f"JOIN|{room_code}")
    guest_lobby = guest.wait("LOBBY")
    check("misafir lobiye girdi", guest_lobby is not None)
    check("lobide 2 oyuncu var", len(guest_lobby.split("|")[3].split(";")) == 2)

    print("3) Bot ekleme")
    guest.send("BOT|2")
    time.sleep(0.6)
    guest._pump()
    lobby_line = [l for l in guest.lines if l.startswith("LOBBY|")][-1]
    check("botlar eklendi", len(lobby_line.split("|")[3].split(";")) == 4)

    print("4) Hile sunucuya gidiyor (misafir odada 'always impostor')")
    guest.send("SETCH|alwaysImpostor|1")
    time.sleep(0.5)
    # Oyunu oda sahibi (host) baslatir
    host.send("START")
    time.sleep(1.5)
    guest._pump()
    host._pump()

    guest_snaps = guest.collect("SNAP", 2.0)
    check("SNAP geldi", len(guest_snaps) > 0)
    if guest_snaps:
        snap = parse_snapshot(guest_snaps[-1].split("|", 1)[1])
        me = [p for p in snap["players"] if p["id"] == snap["localPlayerId"]]
        check("misafir kendi rolünü görüyor", bool(me))
        check(
            "misafir HİLECİ oldu (always impostor)",
            bool(me) and me[0]["role"] == "I",
            me[0]["role"] if me else "oyuncu yok",
        )
        others = [p for p in snap["players"] if p["id"] != snap["localPlayerId"]]
        check("başkalarının rolü gizli", all(p["role"] == "?" for p in others))

    print("5) Impostor Finder (revealRoles) herkeste rolü açıyor")
    # Misafir oyuncu kendi hilesini baska bir odada da acabilir
    guest.send("SETCH|revealRoles|1")
    time.sleep(1.0)
    guest._pump()
    snaps = guest.collect("SNAP", 1.5)
    if snaps:
        snap = parse_snapshot(snaps[-1].split("|", 1)[1])
        check("tüm roller açık", all(p["role"] != "?" for p in snap["players"]))

    print("6) Kill All")
    guest.send("KILLALL")
    time.sleep(1.2)
    guest._pump()
    over = guest.wait("OVER")
    check("oyun bitti (OVER)", over is not None)
    if over:
        check("hileciler kazandı", "IMPOSTORS" in over, over)

    print("7) Kick All")
    guest2 = Client("Üçüncü", args.port, 5)
    guest2.wait("OK")
    guest2.send(f"JOIN|{room_code}")
    guest2.wait("LOBBY")
    time.sleep(0.4)
    guest.send("KICKALL")
    time.sleep(1.0)
    err = guest2.wait("ERR")
    check("atılan oyuncu hata aldı", err is not None and "atıld" in err, err or "")

    host.close()
    guest.close()
    guest2.close()

    print()
    if failures:
        print(f"BAŞARISIZ: {len(failures)} test -> {failures}")
        return 1
    print("TÜM TESTLER GEÇTİ ✓")
    return 0


if __name__ == "__main__":
    sys.exit(main())
