import org.gradle.jvm.tasks.Jar

plugins {
    alias(libs.plugins.kotlin.jvm)
    application
}

kotlin {
    jvmToolchain(17)
}

application {
    mainClass.set("com.amongushile.server.MainKt")
}

dependencies {
    implementation(project(":core"))
}

/** Tek dosya, çalıştırılabilir sunucu paketi: java -jar amongushile-server.jar */
tasks.register<Jar>("fatJar") {
    group = "build"
    description = "Çalıştırılabilir sunucu jar'ı üretir"
    archiveFileName.set("amongushile-server.jar")
    manifest {
        attributes["Main-Class"] = "com.amongushile.server.MainKt"
    }
    from(sourceSets.main.get().output)
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    from({
        configurations.runtimeClasspath.get()
            .filter { it.name.endsWith(".jar") }
            .map { zipTree(it) }
    })
}
