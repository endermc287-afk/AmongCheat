package com.amongushile.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineTest {

    private fun newEngine(cheats: CheatSettings = CheatSettings(), bots: Int = 5): GameEngine {
        val engine = GameEngine(GameConfig(playerCount = bots + 1, taskCount = 3), cheats)
        val me = engine.addPlayer("Ben", 0, isBot = false)
        engine.localPlayerId = me.id
        repeat(bots) { engine.addPlayer("Bot $it", it + 1, isBot = true) }
        return engine
    }

    @Test
    fun `rol dagitimi dogru`() {
        val engine = newEngine()
        engine.start()
        assertEquals(Phase.PLAYING, engine.phase)
        assertEquals(1, engine.aliveImpostors().size)
        assertEquals(5, engine.aliveCrew().size)
    }

    @Test
    fun `always impostor yerel oyuncuyu hileci yapar`() {
        val engine = newEngine(CheatSettings(alwaysImpostor = true))
        engine.start()
        val me = engine.playerById(engine.localPlayerId)!!
        assertEquals(Role.IMPOSTOR, me.role)
    }

    @Test
    fun `always impostor oyuncu bazli calisir`() {
        val engine = newEngine()
        val bot = engine.players.first { it.isBot }
        engine.alwaysImpostorIds.add(bot.id)
        engine.start()
        assertEquals(Role.IMPOSTOR, bot.role)
    }

    @Test
    fun `gorev yalnizca istasyona yakinken tamamlanir`() {
        val engine = newEngine()
        engine.start()
        val me = engine.playerById(engine.localPlayerId)!!
        val myTasks = engine.assignments[me.id]!!.toList()
        assertTrue(myTasks.isNotEmpty())

        // Uzaktayken tamamlanamaz
        assertFalse(engine.completeTask(me.id, myTasks[0]))

        // İstasyona yaklaş
        val station = engine.map.taskStations.first { it.id == myTasks[0] }
        me.x = station.pos.x
        me.y = station.pos.y
        assertTrue(engine.completeTask(me.id, myTasks[0]))
        assertEquals(1, me.tasksDone)
        // Aynı görev tekrar tamamlanamaz
        assertFalse(engine.completeTask(me.id, myTasks[0]))
    }

    @Test
    fun `oldurme ceset olusturur ve bekleme suresi uygular`() {
        val engine = newEngine()
        engine.start()
        val killer = engine.aliveImpostors().first()
        val victim = engine.aliveCrew().first()
        killer.x = victim.x
        killer.y = victim.y

        assertTrue(engine.tryKill(killer.id, victim.id))
        assertFalse(victim.alive)
        assertEquals(1, engine.bodies.size)
        assertTrue(engine.killCooldown > 0f)

        // Bekleme süresi dolmadan ikinci öldürme olmaz
        val victim2 = engine.aliveCrew().firstOrNull()
        if (victim2 != null) {
            killer.x = victim2.x
            killer.y = victim2.y
            assertFalse(engine.tryKill(killer.id, victim2.id))
        }
    }

    @Test
    fun `skip kill cooldown bekleme suresini kaldirir`() {
        val engine = newEngine(CheatSettings(skipKillCooldown = true))
        engine.start()
        val killer = engine.aliveImpostors().first()
        val victim = engine.aliveCrew().first()
        killer.x = victim.x
        killer.y = victim.y
        assertTrue(engine.tryKill(killer.id, victim.id))
        assertEquals(0f, engine.killCooldown, 0.001f)
    }

    @Test
    fun `acil toplanti baslar ve oylama atis yapar`() {
        val engine = newEngine()
        engine.start()
        val me = engine.playerById(engine.localPlayerId)!!
        assertTrue(engine.callEmergency(me.id))
        assertEquals(Phase.MEETING, engine.phase)

        // Tartisma suresi bitip oylamaya gecmesi gerekir
        engine.update(26f)
        val target = engine.aliveCrew().first { it.id != me.id }
        assertTrue(engine.castVote(me.id, target.id))
        assertEquals(target.id, engine.meeting!!.votes[me.id])

        engine.resolveVote()
        assertEquals(target.id, engine.meeting!!.ejectedId)
        assertFalse(engine.playerById(target.id)!!.alive)
    }

    @Test
    fun `toplantilar kapatma hilesi toplanti baslatmaz`() {
        val engine = newEngine(CheatSettings(noMeetings = true))
        engine.start()
        val me = engine.playerById(engine.localPlayerId)!!
        assertFalse(engine.callEmergency(me.id))
        assertEquals(Phase.PLAYING, engine.phase)
    }

    @Test
    fun `kill all hilesi hicileri kazandirir`() {
        val engine = newEngine()
        engine.start()
        engine.killAllCheat()
        assertEquals(Winner.IMPOSTORS, engine.winner)
        assertEquals(Phase.GAME_OVER, engine.phase)
    }

    @Test
    fun `impostor sayisi ayarlanabilir`() {
        val engine = newEngine(CheatSettings(impostorCount = 2))
        engine.start()
        assertEquals(2, engine.aliveImpostors().size)
    }

    @Test
    fun `sabotaj sayaci sonunda hiciler kazanir`() {
        val engine = newEngine()
        engine.start()
        val impostor = engine.aliveImpostors().first()
        assertTrue(engine.triggerSabotage(impostor.id, SabotageType.OXYGEN))
        // 60 saniyelik geri sayim
        repeat(70) { engine.update(1f) }
        assertEquals(Winner.IMPOSTORS, engine.winner)
    }

    @Test
    fun `hiz hilesi hareket mesafesini artirir`() {
        val slow = newEngine()
        slow.start()
        val fast = newEngine(CheatSettings(walkSpeedMultiplier = 2f))
        fast.start()

        val slowMe = slow.playerById(slow.localPlayerId)!!
        val fastMe = fast.playerById(fast.localPlayerId)!!

        val slowStart = slowMe.pos()
        val fastStart = fastMe.pos()
        repeat(30) {
            slow.update(0.1f, mapOf(slowMe.id to Input(moveX = 1f, moveY = 0f)))
            fast.update(0.1f, mapOf(fastMe.id to Input(moveX = 1f, moveY = 0f)))
        }
        val slowDist = slowStart.dist(slowMe.pos())
        val fastDist = fastStart.dist(fastMe.pos())
        assertTrue("Hız hilesi daha uzağa taşımalı", fastDist > slowDist)
    }

    @Test
    fun `aninda gorev hilesi sureyi kisaltir`() {
        val engine = newEngine(CheatSettings(instantTasks = true))
        engine.start()
        val me = engine.playerById(engine.localPlayerId)!!
        val taskId = engine.assignments[me.id]!!.first()
        val station = engine.map.taskStations.first { it.id == taskId }
        me.x = station.pos.x
        me.y = station.pos.y
        assertTrue(engine.completeTask(me.id, taskId))
    }

    @Test
    fun `anlik goruntu yerel oyuncunun rolunu gosterir digerlerini gizler`() {
        val engine = newEngine()
        engine.start()
        val snap = engine.snapshot()
        assertNotNull(snap.players.first { it.id == engine.localPlayerId }.role)
        assertEquals(null, snap.players.first { it.id != engine.localPlayerId }.role)
    }

    @Test
    fun `rol gosterme hilesi tum rolleri aciklar`() {
        val engine = newEngine(CheatSettings(revealRoles = true))
        engine.start()
        val snap = engine.snapshot()
        assertTrue(snap.players.all { it.role != null })
    }

    @Test
    fun `havalandirma hileci tarafindan kullanilabilir`() {
        val engine = newEngine()
        engine.start()
        val impostor = engine.aliveImpostors().first()
        val vent = engine.map.vents.first()
        impostor.x = vent.pos.x
        impostor.y = vent.pos.y
        val target = engine.map.vents.first { it.id == vent.links.first() }
        assertTrue(engine.useVent(impostor.id, target.id))
        assertEquals(target.pos.x, impostor.x, 0.01f)
    }
}
