package com.amongushile.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProtocolTest {

    @Test
    fun `snapshot gidis gelis ayni bilgiyi tasiyor`() {
        val players = listOf(
            PlayerView(1, "Ali", 0, Role.IMPOSTOR, 100f, 200f, true, false, true, 2, 5, false),
            PlayerView(2, "Veli", 3, null, 320.5f, 410f, false, true, true, 0, 0, false),
        )
        val snapshot = GameSnapshot(
            phase = Phase.PLAYING,
            localPlayerId = 1,
            players = players,
            tasks = ShipMap.STANDARD.taskStations,
            completedTasks = setOf(1, 3),
            myTasks = listOf(1, 3, 5),
            totalTaskSlots = 20,
            globalTasksDone = 6,
            sabotage = SabotageState(SabotageType.LIGHTS, 12.5f),
            bodies = listOf(Body(1, 50f, 60f, 2, false)),
            winner = null,
            cheats = CheatSettings(),
            emergencyUsable = true,
            killCooldown = 4f,
            ventAvailable = true,
        )

        val decoded = Protocol.decodeSnapshot(Protocol.encodeSnapshot(snapshot))!!
        assertEquals(Phase.PLAYING, decoded.phase)
        assertEquals(1, decoded.localPlayerId)
        assertEquals(2, decoded.players.size)
        assertEquals(Role.IMPOSTOR, decoded.players[0].role)
        assertEquals(null, decoded.players[1].role)
        assertEquals(100f, decoded.players[0].x, 0.01f)
        assertEquals(320.5f, decoded.players[1].x, 0.01f)
        assertEquals(setOf(1, 3), decoded.completedTasks)
        assertEquals(listOf(1, 3, 5), decoded.myTasks)
        assertEquals(SabotageType.LIGHTS, decoded.sabotage!!.type)
        assertEquals(12.5f, decoded.sabotage!!.secondsLeft, 0.01f)
        assertEquals(1, decoded.bodies.size)
        assertTrue(decoded.ventAvailable)
        assertEquals(4f, decoded.killCooldown, 0.01f)
    }

    @Test
    fun `lobi gidis gelis calisiyor`() {
        val players = listOf(
            Player(1, "Ali", 0, Role.CREWMATE),
            Player(2, "Veli", 3, Role.IMPOSTOR),
        )
        val encoded = Protocol.encodeLobby("ABCD", 1, players)
        val decoded = Protocol.decodeLobby(encoded)!!
        assertEquals("ABCD", decoded.first)
        assertEquals(2, decoded.second.size)
        assertEquals("Ali", decoded.second[0].name)
        assertEquals(3, decoded.second[1].colorIndex)
    }

    @Test
    fun `hile bayraklari iki yonlu ayni`() {
        val cheats = CheatSettings(
            alwaysImpostor = true,
            instantTasks = true,
            walkSpeedMultiplier = 2f,
            impostorCount = 3,
            playerEsp = true,
        )
        val flags = GameEngine.flagsFromCheats(cheats)
        val back = GameEngine.cheatsFromFlags(flags)
        assertTrue(back.alwaysImpostor)
        assertTrue(back.instantTasks)
        assertTrue(back.playerEsp)
        assertEquals(3, back.impostorCount)
        assertEquals(2f, back.walkSpeedMultiplier, 0.01f)
    }

    @Test
    fun `ozel karakterler protokolu bozmaz`() {
        val escaped = Protocol.escape("a|b\nc")
        assertTrue(!escaped.contains("|"))
        assertTrue(!escaped.contains("\n"))
    }
}

class MapTest {

    @Test
    fun `odalar ve koridorlar yurunebilir`() {
        val map = ShipMap.STANDARD
        assertTrue(map.rooms.size >= 10)
        map.rooms.forEach { room ->
            assertTrue(map.isWalkable(room.rect.center))
        }
    }

    @Test
    fun `duvar disi nokta yurunebilir degil`() {
        val map = ShipMap.STANDARD
        assertTrue(!map.isWalkable(Vec2(-50f, -50f)))
        assertTrue(!map.isWalkable(Vec2(map.width + 50f, map.height + 50f)))
    }

    @Test
    fun `hareket duvari gecmez`() {
        val map = ShipMap.STANDARD
        val start = Vec2(65f, 800f) // Alt Motor odasinin sol kenari
        val moved = map.move(start, Vec2(-100f, 0f))
        assertTrue(map.isWalkable(moved))
        assertTrue(moved.x >= start.x)
    }

    @Test
    fun `yol bulma odalari birlestirir`() {
        val map = ShipMap.STANDARD
        val nav = NavGrid(map)
        val from = map.rooms[0].rect.center
        val to = map.rooms[map.rooms.size - 1].rect.center
        val path = nav.findPath(from, to)
        assertNotNull(path)
        assertTrue(path.isNotEmpty())
    }

    @Test
    fun `gorev istasyonlari odalarin icinde`() {
        val map = ShipMap.STANDARD
        map.taskStations.forEach { station ->
            assertNotNull("İstasyon oda içinde olmalı: ${station.room}", map.roomAt(station.pos))
        }
    }
}
