package com.amongushile.core

import kotlin.math.abs
import kotlin.random.Random

/**
 * Basit bot zekâsı: mürettebat botları görev yapar ve ceset bildirir,
 * hileci botları avlanır, taklit yapar ve sabotaj kurar.
 */
class BotBrain(val playerId: Int) {
    enum class Mode { WANDER, GOTO_TASK, DOING_TASK, REPORT, HUNT }

    var mode: Mode = Mode.WANDER
        private set
    private var path: List<Vec2> = emptyList()
    private var pathIndex: Int = 0
    private var targetStationId: Int = -1
    private var taskTimer: Float = 0f
    private var stuckTimer: Float = 0f
    private var lastPos: Vec2 = Vec2.ZERO
    private var meetingTimer: Float = 0f
    private var sabotageTimer: Float = 0f
    private var emergencyTimer: Float = 0f
    private val random = Random(playerId * 7919L + 13)

    fun reset() {
        mode = Mode.WANDER
        path = emptyList()
        pathIndex = 0
        targetStationId = -1
        taskTimer = 0f
        stuckTimer = 0f
        meetingTimer = 0f
        sabotageTimer = random.nextFloat() * 60f + 20f
        emergencyTimer = random.nextFloat() * 90f + 45f
    }

    private fun setPath(points: List<Vec2>) {
        path = points
        pathIndex = 0
    }

    fun think(engine: GameEngine, nav: NavGrid, dt: Float): Input {
        val p = engine.playerById(playerId) ?: return Input.NONE
        if (!p.alive) return Input.NONE
        if (engine.phase != Phase.PLAYING) return Input.NONE

        // Sıkışma kontrolü
        if (dist(p.x, p.y, lastPos.x, lastPos.y) < 0.4f) {
            stuckTimer += dt
            if (stuckTimer > 1.5f) {
                stuckTimer = 0f
                path = emptyList()
                setPath(nav.findPath(p.pos(), targetPos(engine)))
            }
        } else {
            stuckTimer = 0f
        }
        lastPos = p.pos()

        if (p.role == Role.IMPOSTOR) return thinkImpostor(engine, nav, dt, p)
        return thinkCrewmate(engine, nav, dt, p)
    }

    private fun targetPos(engine: GameEngine): Vec2 {
        val station = engine.map.taskStations.firstOrNull { it.id == targetStationId }
        return station?.pos ?: engine.map.spawns.random(random)
    }

    private fun thinkCrewmate(engine: GameEngine, nav: NavGrid, dt: Float, p: Player): Input {
        // Ceset gördüyse bildir
        val body = engine.bodies.firstOrNull { !it.reported && dist(p.x, p.y, it.x, it.y) <= GameEngine.REPORT_RANGE }
        if (body != null) {
            mode = Mode.REPORT
            engine.tryReportNearBody(p.id)
            return Input.NONE
        }

        val myTasks = engine.assignments[p.id] ?: emptySet()
        val done = engine.completedStations[p.id] ?: emptySet()
        val pending = engine.map.taskStations
            .filter { myTasks.contains(it.id) && !done.contains(it.id) }
            .minByOrNull { dist(p.x, p.y, it.pos.x, it.pos.y) }

        if (pending == null) {
            // Tüm görevler bitti: dolaş
            if (path.isEmpty() || pathIndex >= path.size) {
                val dest = engine.map.spawns.random(random)
                setPath(nav.findPath(p.pos(), dest))
                mode = Mode.WANDER
            }
            return followPath(p)
        }

        if (targetStationId != pending.id) {
            targetStationId = pending.id
            setPath(nav.findPath(p.pos(), pending.pos))
            mode = Mode.GOTO_TASK
        }

        val d = dist(p.x, p.y, pending.pos.x, pending.pos.y)
        if (d <= GameEngine.TASK_RANGE - 10f) {
            mode = Mode.DOING_TASK
            taskTimer += dt
            val required = if (engine.cheats.instantTasks) 0.4f else random.nextFloat() * 2.5f + 2.5f
            if (taskTimer >= required) {
                engine.completeTask(p.id, pending.id)
                taskTimer = 0f
                targetStationId = -1
                path = emptyList()
            }
            return Input.NONE
        }
        return followPath(p)
    }

    private fun thinkImpostor(engine: GameEngine, nav: NavGrid, dt: Float, p: Player): Input {
        // Avlanma: yalnız (yakında başka mürettebat yoksa) öldür
        if (engine.killCooldown <= 0f) {
            val target = engine.aliveCrew()
                .filter { dist(p.x, p.y, it.x, it.y) <= GameEngine.KILL_RANGE }
                .minByOrNull { dist(p.x, p.y, it.x, it.y) }
            if (target != null) {
                val witnesses = engine.aliveCrew().count {
                    it.id != target.id && dist(target.x, target.y, it.x, it.y) <= 220f
                }
                if (witnesses == 0 || random.nextFloat() < 0.12f) {
                    engine.tryKill(p.id, target.id)
                    return Input.NONE
                }
            }
        }

        // Taklit: rastgele bir görev istasyonuna git ve sahte görev "yap"
        if (path.isEmpty() || pathIndex >= path.size) {
            val station = engine.map.taskStations.random(random)
            targetStationId = station.id
            setPath(nav.findPath(p.pos(), station.pos))
            mode = Mode.GOTO_TASK
        }
        val station = engine.map.taskStations.firstOrNull { it.id == targetStationId }
        if (station != null && dist(p.x, p.y, station.pos.x, station.pos.y) <= GameEngine.TASK_RANGE - 10f) {
            taskTimer += dt
            if (taskTimer > 3f) {
                taskTimer = 0f
                path = emptyList()
            }
            return Input.NONE
        }

        // Ara sıra sabotaj
        sabotageTimer -= dt
        if (sabotageTimer <= 0f) {
            sabotageTimer = random.nextFloat() * 70f + 40f
            if (engine.sabotage == null && random.nextFloat() < 0.6f) {
                val type = SabotageType.entries.random(random)
                engine.triggerSabotage(p.id, type)
            }
        }

        // Ara sıra acil toplantı çağır
        emergencyTimer -= dt
        if (emergencyTimer <= 0f) {
            emergencyTimer = random.nextFloat() * 120f + 60f
            if (random.nextFloat() < 0.5f && engine.aliveCrew().size >= 2) {
                engine.callEmergency(p.id)
                return Input.NONE
            }
        }

        return followPath(p)
    }

    private fun followPath(p: Player): Input {
        if (path.isEmpty() || pathIndex >= path.size) return Input.NONE
        val target = path[pathIndex]
        if (dist(p.x, p.y, target.x, target.y) < 14f) {
            pathIndex++
            if (pathIndex >= path.size) return Input.NONE
        }
        val next = path[pathIndex]
        val dir = Vec2(next.x - p.x, next.y - p.y).normalized()
        return Input(moveX = dir.x, moveY = dir.y)
    }
}

/** Toplantı sırasında botların sohbet etmesi ve oy kullanması. */
object BotMeeting {

    private val CREW_LINES = listOf(
        "Ben kesinlikle masumum.",
        "Kanıt yok, atlamalıyız.",
        "Görevleri sırayla yapalım.",
        "Kim o odada göründü?",
        "Ben MedBay'de tek başımaydım.",
        "Suçlayacak bir şeyim yok.",
        "Önce görevleri bitirelim.",
        "Bence {name} şüpheli.",
    )

    private val IMPOSTOR_LINES = listOf(
        "Ben görevlerimi yapıyorum, bana inanmıyorsunuz.",
        "{name} çok sessiz, garip.",
        "Beni sorgulamak zaman kaybı.",
        "Kesin {name} yapmıştır.",
    )

    private val SKIP_LINES = listOf(
        "Kanıt yok.",
        "Grafik seyrelmedi.",
    )

    fun act(engine: GameEngine, dt: Float) {
        val m = engine.meeting ?: return
        for (p in engine.players) {
            if (!p.alive || !p.isBot) continue
            when (m.stage) {
                MeetingStage.DISCUSSION -> {
                    m.chatTimer(p.id, dt)
                    val line = pickLine(p, engine)
                    if (line != null) engine.sendChat(p.id, line)
                }
                MeetingStage.VOTING -> {
                    m.voteTimer(p.id, dt)
                    val alive = engine.players.filter { it.alive }
                    if (alive.size > 1 && random(p.id).nextFloat() < 0.25f) {
                        val target = if (p.role == Role.IMPOSTOR) {
                            alive.filter { it.role != Role.IMPOSTOR }.randomOrNull(random(p.id))?.id ?: -1
                        } else {
                            if (random(p.id).nextFloat() < 0.25f) -1
                            else alive.filter { it.id != p.id }.randomOrNull(random(p.id))?.id ?: -1
                        }
                        if (target != -1) engine.castVote(p.id, target)
                    }
                }
                MeetingStage.RESULT -> Unit
            }
        }
    }

    private fun pickLine(p: Player, engine: GameEngine): String? {
        val rng = random(p.id)
        if (rng.nextFloat() > 0.35f) return null
        val pool = if (p.role == Role.IMPOSTOR) IMPOSTOR_LINES else CREW_LINES
        var line = pool.random(rng)
        val others = engine.players.filter { it.id != p.id && it.alive }
        if (others.isNotEmpty() && line.contains("{name}")) {
            line = line.replace("{name}", others.random(rng).name)
        }
        if (rng.nextFloat() < 0.2f) line = SKIP_LINES.random(rng)
        return line
    }

    private fun random(id: Int) = Random(id * 31L + System.nanoTime() / 1_000_000L)

    private fun Meeting.chatTimer(playerId: Int, dt: Float) {
        // Sohbeti seyreltmek için basit zamanlayıcı
        chatTimers[playerId] = (chatTimers[playerId] ?: 0f) - dt
        if ((chatTimers[playerId] ?: 0f) <= 0f) {
            chatTimers[playerId] = 4f + random(playerId).nextFloat() * 6f
        }
    }

    private fun Meeting.voteTimer(playerId: Int, dt: Float) {
        voteTimers[playerId] = (voteTimers[playerId] ?: 0f) - dt
        if ((voteTimers[playerId] ?: 0f) <= 0f) {
            voteTimers[playerId] = 3f + random(playerId).nextFloat() * 5f
        }
    }

    private val chatTimers = mutableMapOf<Int, Float>()
    private val voteTimers = mutableMapOf<Int, Float>()
}

/** Yardımcı: mutlak fark. */
private fun absDiff(a: Float, b: Float): Float = abs(a - b)
