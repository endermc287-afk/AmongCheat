package com.amongushile.core

import kotlin.math.abs
import kotlin.math.sqrt

/** Temel 2B vektör (saf Kotlin, Android bağımsız). */
data class Vec2(val x: Float = 0f, val y: Float = 0f) {
    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(s: Float) = Vec2(x * s, y * s)
    fun len(): Float = sqrt(x * x + y * y)
    fun dist(o: Vec2): Float = (this - o).len()
    fun normalized(): Vec2 {
        val l = len()
        return if (l < 0.0001f) Vec2(0f, 0f) else Vec2(x / l, y / l)
    }
    fun coerceInBox(w: Float, h: Float): Vec2 = Vec2(x.coerceIn(0f, w), y.coerceIn(0f, h))
    companion object {
        val ZERO = Vec2(0f, 0f)
    }
}

/** Dikdörtgen (sol-üst köşe + boyut). */
data class Rect(val x: Float, val y: Float, val w: Float, val h: Float) {
    val right: Float get() = x + w
    val bottom: Float get() = y + h
    val center: Vec2 get() = Vec2(x + w / 2f, y + h / 2f)
    fun contains(p: Vec2, pad: Float = 0f): Boolean =
        p.x >= x - pad && p.x <= right + pad && p.y >= y - pad && p.y <= bottom + pad
    fun inflate(r: Float) = Rect(x - r, y - r, w + 2 * r, h + 2 * r)
    fun overlaps(o: Rect): Boolean =
        x < o.right && right > o.x && y < o.bottom && bottom > o.y
}

/** Oyuncunun rolü. */
enum class Role(val labelTr: String) {
    CREWMATE("Mürettebat"),
    IMPOSTOR("Hileci");

    companion object {
        fun fromName(v: String): Role = entries.firstOrNull { it.name == v } ?: CREWMATE
    }
}

/**
 * Hile (mod) ayarları. Hem yerel antrenmanda hem de kendi sunucunda gerçekten uygulanır.
 * Gerçek Among Us istemcisinin belleğini değiştirmek root gerektirir; biz root'suz çalışırız.
 */
data class CheatSettings(
    val alwaysImpostor: Boolean = false,
    val noMeetings: Boolean = false,
    val instantTasks: Boolean = false,
    val skipKillCooldown: Boolean = false,
    val freeCamera: Boolean = false,
    val unlockSkins: Boolean = false,
    val walkSpeedMultiplier: Float = 1f,
    val impostorCount: Int = 1,
    val ghostMode: Boolean = false,
    val playerEsp: Boolean = false,
    val revealRoles: Boolean = false,
    val noVoteCooldown: Boolean = false,
) {
    /** Aktif hile sayısı (menüde rozet olarak gösterilir). */
    val activeCount: Int
        get() = listOf(
            alwaysImpostor, noMeetings, instantTasks, skipKillCooldown, freeCamera,
            unlockSkins, walkSpeedMultiplier > 1.01f, impostorCount > 1, ghostMode,
            playerEsp, revealRoles, noVoteCooldown
        ).count { it }
}

/** Görev paneli minigamelerinin türleri. */
enum class TaskKind(val labelTr: String) {
    WIRES("Kablo Bağla"),
    CARD("Kart Oku"),
    KEYPAD("Şifre Gir"),
    CALIBRATE("Kalibre Et"),
    TRASH("Çöp At"),
    SCAN("Tarama"),
}

data class TaskStation(
    val id: Int,
    val room: String,
    val pos: Vec2,
    val kind: TaskKind,
    val title: String,
)

/** İmposterların kullanabildiği havalandırma noktaları. */
data class Vent(val id: Int, val room: String, val pos: Vec2, val links: List<Int>)

enum class Phase { LOBBY, PLAYING, MEETING, EJECTING, GAME_OVER }

enum class MeetingReason { BODY, BUTTON, SABOTAGE }

enum class MeetingStage { DISCUSSION, VOTING, RESULT }

enum class Winner { CREWMATES, IMPOSTORS }

enum class SabotageType(val labelTr: String) {
    REACTOR("Santral Arızası"),
    LIGHTS("Işıklar"),
    OXYGEN("Oksijen Tükeniyor"),
}

data class SabotageState(val type: SabotageType, val secondsLeft: Float, val fixed: Boolean = false)

data class ChatMessage(val id: Int, val playerId: Int, val name: String, val text: String, val system: Boolean = false)

data class Body(val id: Int, val x: Float, val y: Float, val colorIndex: Int, var reported: Boolean = false)

/** Oyuncu güncel durumu (motor içinde yaşayan hali). */
class Player(
    val id: Int,
    val name: String,
    val colorIndex: Int,
    var role: Role = Role.CREWMATE,
    var x: Float = 0f,
    var y: Float = 0f,
    var alive: Boolean = true,
    var isBot: Boolean = false,
    var connected: Boolean = true,
    var tasksDone: Int = 0,
    var taskTotal: Int = 0,
    var inVent: Boolean = false,
) {
    fun pos(): Vec2 = Vec2(x, y)
    fun copy(): Player = Player(id, name, colorIndex, role, x, y, alive, isBot, connected, tasksDone, taskTotal, inVent)
}

/** Arayüz/sunucu için oyuncu görünümü. */
data class PlayerView(
    val id: Int,
    val name: String,
    val colorIndex: Int,
    /** null -> rol gizli (istemciye sızdırılmaz). */
    val role: Role?,
    val x: Float,
    val y: Float,
    val alive: Boolean,
    val isBot: Boolean,
    val connected: Boolean,
    val tasksDone: Int,
    val taskTotal: Int,
    val inVent: Boolean,
)

/** Toplantı durumu. */
class Meeting(
    val reason: MeetingReason,
    val callerId: Int,
    val bodyId: Int = -1,
    val bodyPos: Vec2 = Vec2.ZERO,
    var stage: MeetingStage = MeetingStage.DISCUSSION,
    var discussionLeft: Float = 25f,
    var votingLeft: Float = 30f,
    val votes: MutableMap<Int, Int> = mutableMapOf(),
    val chat: MutableList<ChatMessage> = mutableListOf(),
    var ejectedId: Int = -1,
    var ejectedWasImpostor: Boolean = false,
    var resultTimer: Float = 0f,
)

/** Render + arayüz için tam anlık görüntü. */
data class GameSnapshot(
    val phase: Phase = Phase.LOBBY,
    val localPlayerId: Int = -1,
    val players: List<PlayerView> = emptyList(),
    val tasks: List<TaskStation> = emptyList(),
    val completedTasks: Set<Int> = emptySet(),
    val myTasks: List<Int> = emptyList(),
    val totalTaskSlots: Int = 0,
    val globalTasksDone: Int = 0,
    val sabotage: SabotageState? = null,
    val bodies: List<Body> = emptyList(),
    val meeting: Meeting? = null,
    val winner: Winner? = null,
    val cheats: CheatSettings = CheatSettings(),
    val emergencyUsable: Boolean = true,
    val killCooldown: Float = 0f,
    val ventAvailable: Boolean = false,
    val message: String = "",
)

/** Oyun girişleri (hareket + aksiyon istekleri). */
data class Input(
    val moveX: Float = 0f,
    val moveY: Float = 0f,
    val use: Boolean = false,
    val kill: Boolean = false,
    val taskDone: Boolean = false,
    val report: Boolean = false,
    val emergency: Boolean = false,
) {
    companion object {
        val NONE = Input()
    }
}

data class GameConfig(
    val playerCount: Int = 8,
    val taskCount: Int = 5,
    val impostorCount: Int = 1,
    val mapName: String = "Hileci Gemi",
    val seed: Long = 20261L,
)

/** Oyuncu renkleri (Among Us paletinden esinlenmiş). */
object Colors {
    val PALETTE = listOf(
        0xFFD3D3D3.toInt() to "Beyaz",
        0xFFD9A0C9.toInt() to "Pembe",
        0xFF9C7AC8.toInt() to "Mor",
        0xFFF5CD56.toInt() to "Sarı",
        0xFF63C358.toInt() to "Yeşil",
        0xFFF08080.toInt() to "Kırmızı",
        0xFF50B8F5.toInt() to "Mavi",
        0xFF0E9C48.toInt() to "Koyu Yeşil",
        0xFFEB6B62.toInt() to "Koral",
        0xFF9BA19B.toInt() to "Gri",
        0xFF6B3F26.toInt() to "Kahve",
        0xFF3F8FCC.toInt() to "Lacivert",
    )

    fun color(index: Int): Int = PALETTE[index.mod(PALETTE.size)].first
    fun name(index: Int): String = PALETTE[index.mod(PALETTE.size)].second

    /** İsimde ağ protokolü için güvenli karakterler kalsın. */
    fun sanitizeName(raw: String): String {
        val cleaned = raw.filter { it.isLetterOrDigit() || it == ' ' || it == '-' || it == '_' }
            .trim()
            .ifEmpty { "Oyuncu" }
        return cleaned.take(14)
    }
}

/** Basit yardımcı: iki değer arası yumuşak geçiş yok, doğrudan clamp. */
fun clamp(v: Float, min: Float, max: Float): Float = if (v < min) min else if (v > max) max else v

fun dist(ax: Float, ay: Float, bx: Float, by: Float): Float {
    val dx = ax - bx
    val dy = ay - by
    return sqrt(dx * dx + dy * dy)
}

fun approxEq(a: Float, b: Float, eps: Float = 0.001f): Boolean = abs(a - b) < eps
