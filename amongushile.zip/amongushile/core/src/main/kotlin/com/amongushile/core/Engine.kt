package com.amongushile.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** Oyuncu bir şey kullandığında dönen sonuç (arayüz bunu gösterir). */
sealed class UseResult {
    object None : UseResult()
    data class Task(val station: TaskStation) : UseResult()
    object Vent : UseResult()
    data class ReportBody(val bodyId: Int) : UseResult()
    object Emergency : UseResult()
    data class Message(val text: String) : UseResult()
}

/**
 * Oyun motoru. Hem yerel antrenmanda (Android cihazda) hem de kendi sunucunda
 * çalışır; aynı kuralları uygular.
 */
class GameEngine(
    val config: GameConfig = GameConfig(),
    var cheats: CheatSettings = CheatSettings(),
    private val random: Random = Random(config.seed),
) {
    val map: ShipMap = ShipMap.STANDARD
    private val nav: NavGrid = NavGrid(map)

    val players = mutableListOf<Player>()
    val bodies = mutableListOf<Body>()

    var phase: Phase = Phase.LOBBY
        private set
    var winner: Winner? = null
        private set
    var message: String = ""
    var localPlayerId: Int = -1
    var killCooldown: Float = 0f
        private set
    var emergencyCooldown: Float = 0f
        private set
    var sabotage: SabotageState? = null
    var meeting: Meeting? = null
    var ejectTimer: Float = 0f
        private set

    /** "Her Zaman Hileci" isteyen oyuncu id'leri (online lobide sunucu bunu doldurur). */
    val alwaysImpostorIds = mutableSetOf<Int>()

    /** Oyuncu id -> atanmış görev istasyonları. */
    val assignments = mutableMapOf<Int, MutableSet<Int>>()
    /** İsteyen oyuncu -> "true" (görev tamamlandı). */
    val completedStations = mutableMapOf<Int, MutableSet<Int>>()

    private var bodySeq = 1
    private var chatSeq = 1
    private val brains = mutableMapOf<Int, BotBrain>()

    // ---------------------------------------------------------------- oyuncular

    fun addPlayer(name: String, colorIndex: Int, isBot: Boolean): Player {
        val used = players.map { it.colorIndex }.toSet()
        var color = colorIndex
        while (used.contains(color)) color = (color + 1) % Colors.PALETTE.size
        val p = Player(
            id = nextPlayerId(),
            name = Colors.sanitizeName(name),
            colorIndex = color,
            isBot = isBot,
        )
        players += p
        if (isBot) brains[p.id] = BotBrain(p.id)
        return p
    }

    private var playerSeq = 0
    private fun nextPlayerId(): Int {
        playerSeq += 1
        return playerSeq
    }

    fun removePlayer(id: Int) {
        players.removeAll { it.id == id }
        brains.remove(id)
    }

    fun playerById(id: Int): Player? = players.firstOrNull { it.id == id }

    fun aliveCrew(): List<Player> = players.filter { it.alive && it.role == Role.CREWMATE }
    fun aliveImpostors(): List<Player> = players.filter { it.alive && it.role == Role.IMPOSTOR }

    // ---------------------------------------------------------------- başlangıç

    fun start() {
        if (players.size < 2) return
        phase = Phase.PLAYING
        winner = null
        bodies.clear()
        assignments.clear()
        completedStations.clear()
        meeting = null
        sabotage = null
        message = ""

        val shuffle = players.shuffled(random)
        val impostorTotal = cheats.impostorCount.coerceIn(1, max(1, players.size / 2))
        val impostorIds = shuffle.take(impostorTotal).map { it.id }.toMutableSet()

        players.forEachIndexed { index, p ->
            p.x = map.spawns[index % map.spawns.size].x
            p.y = map.spawns[index % map.spawns.size].y
            p.alive = true
            p.inVent = false
            p.tasksDone = 0
            // "Her Zaman Hileci" hilesi: isteyen oyuncu daima hileci olur.
            if ((cheats.alwaysImpostor && p.id == localPlayerId) || alwaysImpostorIds.contains(p.id)) {
                impostorIds.add(p.id)
            }
            p.role = if (impostorIds.contains(p.id)) Role.IMPOSTOR else Role.CREWMATE
            p.taskTotal = if (p.role == Role.IMPOSTOR) 0 else config.taskCount
            p.tasksDone = 0
        }

        // Görev dağılımı: her mürettebat farklı istasyonlar
        val stations = map.taskStations.shuffled(random)
        for (p in players.filter { it.role == Role.CREWMATE }) {
            val set = mutableSetOf<Int>()
            var i = 0
            while (set.size < min(p.taskTotal, stations.size)) {
                set += stations[(p.id * 3 + i) % stations.size].id
                i++
            }
            assignments[p.id] = set
            completedStations[p.id] = mutableSetOf()
        }
        for (p in players.filter { it.role == Role.IMPOSTOR }) {
            assignments[p.id] = mutableSetOf()
            completedStations[p.id] = mutableSetOf()
        }

        killCooldown = 0f
        emergencyCooldown = 0f
        brains.values.forEach { it.reset() }
        systemMessage("Oyun başladı! Hileci: ${players.filter { it.role == Role.IMPOSTOR }.size}")
    }

    // ---------------------------------------------------------------- ana döngü

    fun update(dt: Float, inputs: Map<Int, Input> = emptyMap()) {
        when (phase) {
            Phase.PLAYING -> updatePlaying(dt, inputs)
            Phase.MEETING -> updateMeeting(dt)
            Phase.EJECTING -> {
                ejectTimer -= dt
                if (ejectTimer <= 0f) {
                    meeting = null
                    phase = Phase.PLAYING
                    checkWinConditions()
                }
            }
            else -> Unit
        }
    }

    private fun updatePlaying(dt: Float, inputs: Map<Int, Input>) {
        killCooldown = max(0f, killCooldown - dt)
        emergencyCooldown = max(0f, emergencyCooldown - dt)

        // Sabotaj geri sayımı
        sabotage?.let { sab ->
            if (!sab.fixed) {
                val left = sab.secondsLeft - dt
                if (left <= 0f) {
                    finishGame(Winner.IMPOSTORS)
                    return
                }
                sabotage = sab.copy(secondsLeft = left)
            }
        }

        // Oyuncu hareketi
        for (p in players) {
            if (!p.alive) continue
            val input = if (p.isBot) botInput(p, dt) else inputs[p.id] ?: Input.NONE
            val speed = BASE_SPEED * cheats.walkSpeedMultiplier
            val delta = Vec2(input.moveX, input.moveY).normalized().times(speed * dt)
            val target = map.move(p.pos(), delta)
            p.x = target.x
            p.y = target.y

            if (input.kill) tryKill(p.id, nearestTargetFor(p))
            if (input.report) tryReportNearBody(p.id)
            if (input.taskDone) currentStationFor(p.id)?.let { completeTask(p.id, it.id) }
            if (input.emergency) callEmergency(p.id)
            if (input.use) handleUse(p.id)
        }

        // Ölü mürettebatlar hayalet olarak dolaşabilir (hile açıksa tamamen görünmez)
        for (p in players.filter { !it.alive }) {
            if (!cheats.ghostMode) continue
            val input = if (p.isBot) botInput(p, dt) else inputs[p.id] ?: Input.NONE
            val speed = BASE_SPEED * cheats.walkSpeedMultiplier
            val delta = Vec2(input.moveX, input.moveY).normalized().times(speed * dt)
            val target = map.move(p.pos(), delta)
            p.x = target.x
            p.y = target.y
        }

        checkWinConditions()
    }

    private fun checkWinConditions() {
        if (phase != Phase.PLAYING || winner != null) return
        val impostors = aliveImpostors()
        val crew = aliveCrew()
        if (impostors.isEmpty()) {
            finishGame(Winner.CREWMATES)
            return
        }
        if (crew.isEmpty()) {
            finishGame(Winner.IMPOSTORS)
            return
        }
        // Imposterler crew sayisi kadar olunca kazanir (en az 3 oyuncu olmalı ki
        // 2 kişilik lobiler anında bitmesin)
        if (impostors.size >= crew.size && players.size >= 3) {
            finishGame(Winner.IMPOSTORS)
            return
        }
        if (!cheats.noMeetings && totalTasksDone() >= totalTaskSlots() && totalTaskSlots() > 0) {
            finishGame(Winner.CREWMATES)
        }
    }

    fun totalTaskSlots(): Int =
        players.filter { it.role == Role.CREWMATE }.sumOf { max(0, it.taskTotal) }

    fun totalTasksDone(): Int =
        players.filter { it.role == Role.CREWMATE }.sumOf { p ->
            completedStations[p.id]?.count { stations -> stations in (assignments[p.id] ?: emptySet()) } ?: 0
        }

    fun finishGame(winner: Winner) {
        this.winner = winner
        phase = Phase.GAME_OVER
        meeting = null
        message = if (winner == Winner.CREWMATES) "Mürettebat kazandı!" else "Hileciler kazandı!"
    }

    // ---------------------------------------------------------------- eylemler

    fun currentStationFor(playerId: Int): TaskStation? {
        val p = playerById(playerId) ?: return null
        val myTasks = assignments[playerId] ?: emptySet()
        return map.taskStations
            .filter { myTasks.contains(it.id) }
            .filter { completedStations[playerId]?.contains(it.id) != true }
            .minByOrNull { dist(p.x, p.y, it.pos.x, it.pos.y) }
            ?.takeIf { dist(p.x, p.y, it.pos.x, it.pos.y) <= TASK_RANGE }
    }

    fun handleUse(playerId: Int): UseResult {
        val p = playerById(playerId) ?: return UseResult.None
        if (!p.alive) return UseResult.None

        // Ceset bildirme
        bodies.firstOrNull { !it.reported && dist(p.x, p.y, it.x, it.y) <= REPORT_RANGE }?.let {
            startMeeting(playerId, MeetingReason.BODY, it.id, Vec2(it.x, it.y))
            return UseResult.ReportBody(it.id)
        }

        // Görev
        val station = currentStationFor(playerId)
        if (station != null) return UseResult.Task(station)

        // Hileci: havalandırma
        if (p.role == Role.IMPOSTOR) {
            val vent = map.vents.firstOrNull { dist(p.x, p.y, it.pos.x, it.pos.y) <= VENT_RANGE }
            if (vent != null) return UseResult.Vent
        }
        return UseResult.None
    }

    fun useVent(playerId: Int, targetVentId: Int): Boolean {
        val p = playerById(playerId) ?: return false
        if (p.role != Role.IMPOSTOR || !p.alive) return false
        val from = map.vents.firstOrNull { dist(p.x, p.y, it.pos.x, it.pos.y) <= VENT_RANGE } ?: return false
        val to = map.vents.firstOrNull { it.id == targetVentId && from.links.contains(it.id) } ?: return false
        p.x = to.pos.x
        p.y = to.pos.y
        p.inVent = true
        return true
    }

    fun nearestTargetFor(p: Player): Int {
        return aliveCrew()
            .filter { dist(p.x, p.y, it.x, it.y) <= KILL_RANGE }
            .minByOrNull { dist(p.x, p.y, it.x, it.y) }
            ?.id ?: -1
    }

    fun tryKill(playerId: Int, targetId: Int): Boolean {
        val killer = playerById(playerId) ?: return false
        if (killer.role != Role.IMPOSTOR || !killer.alive) return false
        if (killCooldown > 0f) return false
        val target = playerById(targetId) ?: return false
        if (!target.alive || target.role == Role.IMPOSTOR) return false
        if (dist(killer.x, killer.y, target.x, target.y) > KILL_RANGE) return false
        target.alive = false
        target.x = killer.x
        target.y = killer.y
        bodies += Body(bodySeq++, target.x, target.y, target.colorIndex)
        killCooldown = if (cheats.skipKillCooldown) 0f else KILL_COOLDOWN
        return true
    }

    fun tryReportNearBody(playerId: Int): Int {
        val p = playerById(playerId) ?: return -1
        val body = bodies.firstOrNull { !it.reported && dist(p.x, p.y, it.x, it.y) <= REPORT_RANGE } ?: return -1
        startMeeting(playerId, MeetingReason.BODY, body.id, Vec2(body.x, body.y))
        return body.id
    }

    fun completeTask(playerId: Int, stationId: Int): Boolean {
        val p = playerById(playerId) ?: return false
        if (!p.alive || p.role != Role.CREWMATE) return false
        val mine = assignments[playerId] ?: return false
        if (!mine.contains(stationId)) return false
        if (completedStations[playerId]?.contains(stationId) == true) return false
        val station = map.taskStations.firstOrNull { it.id == stationId } ?: return false
        if (dist(p.x, p.y, station.pos.x, station.pos.y) > TASK_RANGE + 40f) return false
        completedStations.getOrPut(playerId) { mutableSetOf() }.add(stationId)
        p.tasksDone = completedStations[playerId]?.size ?: 0
        return true
    }

    fun callEmergency(playerId: Int): Boolean {
        if (phase != Phase.PLAYING) return false
        if (cheats.noMeetings) return false
        if (emergencyCooldown > 0f) return false
        startMeeting(playerId, MeetingReason.BUTTON)
        return true
    }

    fun triggerSabotage(playerId: Int, type: SabotageType): Boolean {
        val p = playerById(playerId) ?: return false
        if (p.role != Role.IMPOSTOR || !p.alive) return false
        if (sabotage != null) return false
        val duration = when (type) {
            SabotageType.REACTOR -> 45f
            SabotageType.LIGHTS -> 30f
            SabotageType.OXYGEN -> 60f
        }
        sabotage = SabotageState(type, duration)
        return true
    }

    /** Sabotajı onar (belirli odada olmak gerekir). */
    fun fixSabotage(playerId: Int): Boolean {
        val p = playerById(playerId) ?: return false
        val sab = sabotage ?: return false
        if (sab.fixed) return false
        val room = when (sab.type) {
            SabotageType.REACTOR -> "Üst Motor"
            SabotageType.LIGHTS -> "Elektrik"
            SabotageType.OXYGEN -> "Hava"
        }
        if (map.roomAt(p.pos())?.name != room) return false
        sabotage = null
        return true
    }

    // ---------------------------------------------------------------- toplantı

    fun startMeeting(callerId: Int, reason: MeetingReason, bodyId: Int = -1, bodyPos: Vec2 = Vec2.ZERO) {
        if (phase != Phase.PLAYING) return
        if (cheats.noMeetings) return
        bodies.firstOrNull { it.id == bodyId }?.reported = true
        phase = Phase.MEETING
        killCooldown = 0f
        val caller = playerById(callerId)
        meeting = Meeting(
            reason = reason,
            callerId = callerId,
            bodyId = bodyId,
            bodyPos = bodyPos,
            discussionLeft = if (caller != null && !caller.alive) 12f else 25f,
        )
        systemMessage(
            when (reason) {
                MeetingReason.BODY -> "${caller?.name ?: "Birisi"} bir ceset buldu!"
                MeetingReason.BUTTON -> "${caller?.name ?: "Birisi"} acil toplantı çağırdı!"
                MeetingReason.SABOTAGE -> "Sabotaj! Acil toplantı!"
            }
        )
    }

    fun sendChat(playerId: Int, text: String) {
        if (phase != Phase.MEETING) return
        val p = playerById(playerId) ?: return
        val clean = text.trim().take(120)
        if (clean.isEmpty()) return
        meeting?.chat?.add(ChatMessage(chatSeq++, p.id, p.name, clean))
    }

    fun castVote(voterId: Int, targetId: Int): Boolean {
        val m = meeting ?: return false
        if (m.stage != MeetingStage.VOTING) return false
        val voter = playerById(voterId) ?: return false
        if (!voter.alive) return false
        m.votes[voterId] = targetId
        return true
    }

    private fun updateMeeting(dt: Float) {
        val m = meeting ?: return
        BotMeeting.act(this, dt)
        when (m.stage) {
            MeetingStage.DISCUSSION -> {
                m.discussionLeft -= dt
                if (m.discussionLeft <= 0f) {
                    m.stage = MeetingStage.VOTING
                    m.votingLeft = if (cheats.noVoteCooldown) 10f else 30f
                    m.chat.add(ChatMessage(chatSeq++, -1, "Sistem", "Oylama başladı!"))
                }
            }
            MeetingStage.VOTING -> {
                m.votingLeft -= dt
                if (m.votingLeft <= 0f) resolveVote()
            }
            MeetingStage.RESULT -> {
                m.resultTimer -= dt
                if (m.resultTimer <= 0f) {
                    phase = Phase.PLAYING
                    meeting = null
                    checkWinConditions()
                }
            }
        }
    }

    fun resolveVote() {
        val m = meeting ?: return
        val alive = players.filter { it.alive }
        val tally = mutableMapOf<Int, Int>()
        var skipVotes = 0
        m.votes.forEach { (voter, target) ->
            if (voter !in alive.map { it.id }) return@forEach
            if (target == -1) {
                skipVotes++
            } else {
                tally[target] = (tally[target] ?: 0) + 1
            }
        }
        val maxVotes = tally.values.maxOrNull() ?: 0
        val candidates = tally.filter { it.value == maxVotes && maxVotes > 0 }.keys.toList()
        val ejected = if (candidates.isEmpty() || skipVotes >= maxVotes) -1 else candidates.random(random)
        m.ejectedId = ejected
        m.ejectedWasImpostor = ejected != -1 && playerById(ejected)?.role == Role.IMPOSTOR
        m.stage = MeetingStage.RESULT
        m.resultTimer = 4f
        phase = Phase.EJECTING
        ejectTimer = 4f
        if (ejected == -1) {
            m.chat.add(ChatMessage(chatSeq++, -1, "Sistem", "Kimse atılmadı."))
        } else {
            val p = playerById(ejected)
            p?.alive = false
            m.chat.add(
                ChatMessage(
                    chatSeq++, -1, "Sistem",
                    "${p?.name ?: "Oyuncu"} dışarı atıldı. ${if (m.ejectedWasImpostor) "Hileciydi!" else "Mürettebattı."}"
                )
            )
        }
    }

    /** Oyun sırasında oyuncuyu anında hileciye çevirir ("Her Zaman Hileci" hilesi). */
    fun forceImpostor(playerId: Int): Boolean {
        val p = playerById(playerId) ?: return false
        if (p.role == Role.IMPOSTOR) return false
        p.role = Role.IMPOSTOR
        p.taskTotal = 0
        p.tasksDone = 0
        assignments[playerId] = mutableSetOf()
        completedStations[playerId] = mutableSetOf()
        return true
    }

    /** Oyun sırasında oyuncuyu mürettebata çevirir. */
    fun forceCrewmate(playerId: Int): Boolean {
        val p = playerById(playerId) ?: return false
        if (p.role == Role.CREWMATE) return false
        p.role = Role.CREWMATE
        p.taskTotal = config.taskCount
        p.tasksDone = 0
        val stations = map.taskStations.shuffled(random)
        val set = mutableSetOf<Int>()
        var i = 0
        while (set.size < min(p.taskTotal, stations.size)) {
            set += stations[(p.id * 3 + i) % stations.size].id
            i++
        }
        assignments[playerId] = set
        completedStations[playerId] = mutableSetOf()
        return true
    }

    /** KILL ALL hilesi: bütün mürettebatları öldürür. */
    fun killAllCheat() {
        for (p in aliveCrew()) {
            p.alive = false
            bodies += Body(bodySeq++, p.x, p.y, p.colorIndex)
        }
        finishGame(Winner.IMPOSTORS)
    }

    fun systemMessage(text: String) {
        meeting?.chat?.add(ChatMessage(chatSeq++, -1, "Sistem", text, system = true))
        if (message.isNotEmpty()) message = "$message | $text"
    }

    // ---------------------------------------------------------------- botlar

    private fun botInput(p: Player, dt: Float): Input {
        val brain = brains[p.id] ?: return Input.NONE
        return brain.think(this, nav, dt)
    }

    // ---------------------------------------------------------------- görüntü

    fun snapshot(): GameSnapshot {
        val localId = localPlayerId
        val myTasks = assignments[localId] ?: emptySet()
        return GameSnapshot(
            phase = phase,
            localPlayerId = localId,
            players = players.map { p ->
                PlayerView(
                    id = p.id,
                    name = p.name,
                    colorIndex = p.colorIndex,
                    role = if (p.id == localId || cheats.revealRoles || !p.alive) p.role else null,
                    x = p.x,
                    y = p.y,
                    alive = p.alive,
                    isBot = p.isBot,
                    connected = p.connected,
                    tasksDone = p.tasksDone,
                    taskTotal = p.taskTotal,
                    inVent = p.inVent,
                )
            },
            tasks = map.taskStations,
            completedTasks = completedStations[localId] ?: emptySet(),
            myTasks = (assignments[localId] ?: emptySet()).sorted(),
            totalTaskSlots = totalTaskSlots(),
            globalTasksDone = totalTasksDone(),
            sabotage = sabotage,
            bodies = bodies.toList(),
            meeting = meeting,
            winner = winner,
            cheats = cheats,
            emergencyUsable = emergencyCooldown <= 0f && !cheats.noMeetings,
            killCooldown = killCooldown,
            ventAvailable = playerById(localId)?.let { p ->
                p.role == Role.IMPOSTOR && p.alive &&
                    map.vents.any { dist(p.x, p.y, it.pos.x, it.pos.y) <= VENT_RANGE }
            } ?: false,
            message = message,
        )
    }

    /** Yerel oyuncunun görev listesi (istasyon id'leri). */
    fun myTaskStations(): List<TaskStation> {
        val mine = assignments[localPlayerId] ?: return emptyList()
        return map.taskStations.filter { mine.contains(it.id) }
    }

    companion object {
        const val BASE_SPEED = 150f
        const val KILL_RANGE = 80f
        const val KILL_COOLDOWN = 25f
        const val TASK_RANGE = 95f
        const val REPORT_RANGE = 70f
        const val VENT_RANGE = 60f

        fun cheatsFromFlags(flags: String): CheatSettings {
            val list = flags.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            val set = list.toSet()
            return CheatSettings(
                alwaysImpostor = set.contains("alwaysImpostor"),
                noMeetings = set.contains("noMeetings"),
                instantTasks = set.contains("instantTasks"),
                skipKillCooldown = set.contains("skipKillCooldown"),
                freeCamera = set.contains("freeCamera"),
                unlockSkins = set.contains("unlockSkins"),
                walkSpeedMultiplier = if (set.contains("speed2x")) 2f else 1f,
                impostorCount = list.count { it == "impostor" } + 1,
                ghostMode = set.contains("ghostMode"),
                playerEsp = set.contains("playerEsp"),
                revealRoles = set.contains("revealRoles"),
                noVoteCooldown = set.contains("noVoteCooldown"),
            )
        }

        fun flagsFromCheats(c: CheatSettings): String {
            val out = mutableListOf<String>()
            if (c.alwaysImpostor) out += "alwaysImpostor"
            if (c.noMeetings) out += "noMeetings"
            if (c.instantTasks) out += "instantTasks"
            if (c.skipKillCooldown) out += "skipKillCooldown"
            if (c.freeCamera) out += "freeCamera"
            if (c.unlockSkins) out += "unlockSkins"
            if (c.walkSpeedMultiplier > 1.01f) out += "speed2x"
            if (c.impostorCount > 1) repeat(c.impostorCount - 1) { out += "impostor" }
            if (c.ghostMode) out += "ghostMode"
            if (c.playerEsp) out += "playerEsp"
            if (c.revealRoles) out += "revealRoles"
            if (c.noVoteCooldown) out += "noVoteCooldown"
            return out.joinToString(",")
        }
    }
}

private fun min(a: Int, b: Int) = if (a < b) a else b
