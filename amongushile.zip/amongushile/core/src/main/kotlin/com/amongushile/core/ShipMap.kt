package com.amongushile.core

import java.util.PriorityQueue
import kotlin.math.ceil
import kotlin.math.hypot

/**
 * "Hileci Gemi" haritası.
 * Çarpışma modeli: yürünebilir alanların birleşimi (odalar + koridorlar).
 * Oyuncu merkezi bu alanların dışına çıkamaz; duvar boyunca kayma (sliding) desteklenir.
 */
class ShipMap(
    val width: Float,
    val height: Float,
    val rooms: List<Room>,
    val walkable: List<Rect>,
    val taskStations: List<TaskStation>,
    val vents: List<Vent>,
    val spawns: List<Vec2>,
) {
    data class Room(val id: Int, val name: String, val rect: Rect, val color: Int)

    fun isWalkable(p: Vec2): Boolean = walkable.any { it.contains(p) }

    /** Hareket: duvarı delmeden kayma. */
    fun move(from: Vec2, delta: Vec2): Vec2 {
        if (isWalkable(from + delta)) return from + delta
        val mx = Vec2(from.x + delta.x, from.y)
        if (isWalkable(mx)) return mx
        val my = Vec2(from.x, from.y + delta.y)
        if (isWalkable(my)) return my
        return from
    }

    fun roomAt(p: Vec2): Room? = rooms.firstOrNull { it.rect.contains(p) }

    fun nearestWalkable(p: Vec2): Vec2 {
        if (isWalkable(p)) return p
        var best = p
        var bestD = Float.MAX_VALUE
        for (r in walkable) {
            val cx = clamp(p.x, r.x + 2f, r.right - 2f)
            val cy = clamp(p.y, r.y + 2f, r.bottom - 2f)
            val d = hypot(cx - p.x, cy - p.y)
            if (d < bestD) {
                bestD = d
                best = Vec2(cx, cy)
            }
        }
        return best
    }

    companion object {
        val STANDARD: ShipMap by lazy { buildStandard() }

        private const val MAP_W = 1800f
        private const val MAP_H = 1060f

        private fun buildStandard(): ShipMap {
            val rooms = mutableListOf<ShipMap.Room>()
            val corridors = mutableListOf<Rect>()
            val stations = mutableListOf<TaskStation>()
            val spawns = mutableListOf<Vec2>()

            val cols = intArrayOf(60, 500, 940, 1380)
            val rows = intArrayOf(60, 400, 740)
            val rw = 360f
            val rh = 260f

            data class RoomDef(val col: Int, val row: Int, val name: String, val color: Int, val task: TaskKind, val taskTitle: String)

            val defs = listOf(
                RoomDef(0, 0, "Üst Motor", 0xFF3C4A63.toInt(), TaskKind.CALIBRATE, "Motor Kalibrasyonu"),
                RoomDef(1, 0, "Tıp Odası", 0xFF3E5A66.toInt(), TaskKind.SCAN, "Medikal Tarama"),
                RoomDef(2, 0, "Depo", 0xFF4A4034.toInt(), TaskKind.TRASH, "Çöp Kutusunu Temizle"),
                RoomDef(3, 0, "Elektrik", 0xFF2E4A57.toInt(), TaskKind.WIRES, "Işık Pano Bağlantısı"),
                RoomDef(0, 1, "Güvenlik", 0xFF45405C.toInt(), TaskKind.SCAN, "Kamera Kontrolü"),
                RoomDef(1, 1, "Yemekhane", 0xFF5A4A3A.toInt(), TaskKind.CARD, "Kart ile Giriş"),
                RoomDef(2, 1, "Silahlar", 0xFF55333A.toInt(), TaskKind.WIRES, "Atölye Kablolama"),
                RoomDef(3, 1, "İletişim", 0xFF3A4658.toInt(), TaskKind.CALIBRATE, "Anten Ayarı"),
                RoomDef(0, 2, "Alt Motor", 0xFF3C4A63.toInt(), TaskKind.TRASH, "Yakıt Doldur"),
                RoomDef(1, 2, "Yönetim", 0xFF43364F.toInt(), TaskKind.KEYPAD, "Şifre Gir"),
                RoomDef(2, 2, "Hava", 0xFF34514F.toInt(), TaskKind.CALIBRATE, "Oksijen Ayarı"),
                RoomDef(3, 2, "Navigasyon", 0xFF2F3F57.toInt(), TaskKind.SCAN, "Yörünge Kontrolü"),
            )

            val rectByDef = mutableMapOf<RoomDef, Rect>()
            for (d in defs) {
                val r = Rect(cols[d.col].toFloat(), rows[d.row].toFloat(), rw, rh)
                rectByDef[d] = r
            }

            defs.forEachIndexed { index, d ->
                val r = rectByDef[d]!!
                rooms += ShipMap.Room(index, d.name, r, d.color)
                spawns += Vec2(r.center.x, r.center.y)
                stations += TaskStation(
                    id = index,
                    room = d.name,
                    pos = Vec2(r.center.x, r.y + 54f),
                    kind = d.task,
                    title = d.taskTitle,
                )
            }

            // Yatay koridorlar (satır içi komşu odalar)
            for (row in 0..2) {
                for (c in 0..2) {
                    val x = cols[c] + rw
                    val y = rows[row] + 90f
                    corridors += Rect(x, y, 80f, 80f)
                }
            }
            // Dikey koridorlar (sütun içi komşu odalar)
            for (col in 0..3) {
                for (r in 0..1) {
                    val x = cols[col] + 140f
                    val y = rows[r] + rh
                    corridors += Rect(x, y, 80f, 80f)
                }
            }

            val vents = listOf(
                Vent(0, "Elektrik", Vec2(rectByDef[defs[3]]!!.right - 60f, rectByDef[defs[3]]!!.center.y), listOf(3)),
                Vent(1, "Depo", Vec2(rectByDef[defs[2]]!!.center.x, rectByDef[defs[2]]!!.center.y), listOf(2)),
                Vent(2, "Hava", Vec2(rectByDef[defs[10]]!!.center.x, rectByDef[defs[10]]!!.center.y), listOf(1)),
                Vent(3, "İletişim", Vec2(rectByDef[defs[7]]!!.right - 60f, rectByDef[defs[7]]!!.center.y), listOf(0)),
            )

            return ShipMap(
                width = MAP_W,
                height = MAP_H,
                rooms = rooms,
                walkable = rooms.map { it.rect } + corridors,
                taskStations = stations,
                vents = vents,
                spawns = spawns,
            )
        }
    }
}

/** Izgara tabanlı A* yol bulma (botlar ve ipuçları için). */
class NavGrid(private val map: ShipMap, private val cell: Float = 20f) {
    private val cols: Int = ceil(map.width / cell).toInt()
    private val rows: Int = ceil(map.height / cell).toInt()
    private val blocked: BooleanArray = BooleanArray(cols * rows)

    init {
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                blocked[r * cols + c] = !map.isWalkable(world(c, r))
            }
        }
    }

    private fun world(c: Int, r: Int) = Vec2(c * cell + cell / 2f, r * cell + cell / 2f)

    private fun cellIndex(p: Vec2): Int {
        val c = clamp(p.x / cell, 0f, (cols - 1).toFloat()).toInt()
        val r = clamp(p.y / cell, 0f, (rows - 1).toFloat()).toInt()
        return r * cols + c
    }

    private fun cellOf(p: Vec2): Pair<Int, Int> {
        val c = clamp(p.x / cell, 0f, (cols - 1).toFloat()).toInt()
        val r = clamp(p.y / cell, 0f, (rows - 1).toFloat()).toInt()
        return c to r
    }

    /** Engelli hücreye denk gelirse en yakın açık hücreyi bulur. */
    private fun nearestOpen(index: Int): Int {
        if (!blocked[index]) return index
        val startR = index / cols
        val startC = index % cols
        for (radius in 1..20) {
            for (dr in -radius..radius) {
                for (dc in -radius..radius) {
                    if (kotlin.math.abs(dr) != radius && kotlin.math.abs(dc) != radius) continue
                    val r = startR + dr
                    val c = startC + dc
                    if (r !in 0 until rows || c !in 0 until cols) continue
                    val idx = r * cols + c
                    if (!blocked[idx]) return idx
                }
            }
        }
        return index
    }

    /** Başlangıçtan hedefe yol (dünya koordinatı listesi, hedef dahil). */
    fun findPath(from: Vec2, to: Vec2): List<Vec2> {
        val startIdx = nearestOpen(cellIndex(from))
        val goalIdx = nearestOpen(cellIndex(to))
        if (startIdx == goalIdx) return listOf(map.nearestWalkable(to))

        val gScore = FloatArray(cols * rows) { Float.MAX_VALUE }
        val cameFrom = IntArray(cols * rows) { -1 }
        val closed = BooleanArray(cols * rows)
        gScore[startIdx] = 0f

        val open = PriorityQueue<Int>(compareBy { gScore[it] + heuristic(it, goalIdx) })
        open.add(startIdx)

        var guard = 0
        while (open.isNotEmpty() && guard < 20000) {
            guard++
            val current = open.poll() ?: break
            if (current == goalIdx) break
            if (closed[current]) continue
            closed[current] = true
            val cr = current / cols
            val cc = current % cols
            for (dr in -1..1) {
                for (dc in -1..1) {
                    if (dr == 0 && dc == 0) continue
                    val nr = cr + dr
                    val nc = cc + dc
                    if (nr !in 0 until rows || nc !in 0 until cols) continue
                    val nIdx = nr * cols + nc
                    if (blocked[nIdx] || closed[nIdx]) continue
                    // Köşe kesmeyi engelle
                    if (dr != 0 && dc != 0) {
                        if (blocked[cr * cols + nc] || blocked[nr * cols + cc]) continue
                    }
                    val step = if (dr == 0 || dc == 0) 1f else 1.4142f
                    val tentative = gScore[current] + step
                    if (tentative < gScore[nIdx]) {
                        gScore[nIdx] = tentative
                        cameFrom[nIdx] = current
                        open.add(nIdx)
                    }
                }
            }
        }

        if (cameFrom[goalIdx] == -1 && startIdx != goalIdx) {
            return listOf(map.nearestWalkable(to))
        }

        val path = ArrayList<Vec2>()
        var node = goalIdx
        while (node != -1) {
            path.add(world(node % cols, node / cols))
            node = cameFrom[node]
        }
        path.reverse()
        return path
    }

    private fun heuristic(a: Int, b: Int): Float {
        val ar = a / cols
        val ac = a % cols
        val br = b / cols
        val bc = b % cols
        return hypot((ar - br).toFloat(), (ac - bc).toFloat())
    }
}
