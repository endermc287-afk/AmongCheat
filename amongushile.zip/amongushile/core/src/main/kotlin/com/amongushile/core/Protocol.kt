package com.amongushile.core

/**
 * Basit satır tabanlı metin protokolü (kendi sunucun <-> Android istemcisi).
 * Format: KOMUT|arg1|arg2|...\n  (UTF-8)
 * Elle yazıldı: harici kütüphane gerektirmez, hata ayıklaması kolay.
 */
object Protocol {

    // -------- İstemci -> Sunucu
    const val HELLO = "HELLO"          // HELLO|name|colorIdx
    const val CREATE = "CREATE"        // CREATE|roomCode
    const val JOIN = "JOIN"            // JOIN|roomCode
    const val START = "START"          // START|cheatFlags
    const val SETCH = "SETCH"          // SETCH|key|value
    const val INPUT = "IN"             // IN|dx|dy
    const val USE = "USE"
    const val KILL = "KILL"            // KILL|targetId
    const val TASK = "TASK"            // TASK|stationId
    const val REPORT = "REPORT"        // REPORT|bodyId
    const val EMERGENCY = "EMERGENCY"
    const val VOTE = "VOTE"            // VOTE|targetId (-1 = atla)
    const val CHAT = "CHAT"            // CHAT|text
    const val PING = "PING"
    const val SAB = "SAB"              // SAB|SabotageType
    const val VENT = "VENT"            // VENT|ventId
    const val BOT = "BOT"              // BOT|adet
    const val KILLALL = "KILLALL"      // tüm mürettebatları öldür (hile)
    const val KICKALL = "KICKALL"      // lobideki diğer oyuncuları at (hile)

    // -------- Sunucu -> İstemci
    const val OK = "OK"
    const val ERR = "ERR"
    const val LOBBY = "LOBBY"          // LOBBY|room|hostId|players
    const val ROLE = "ROLE"            // ROLE|role|allies
    const val SNAP = "SNAP"
    const val MSG = "MSG"              // MSG|text
    const val OVER = "OVER"            // OVER|CREWMATES|IMPOSTORS
    const val PONG = "PONG"

    fun encode(vararg parts: Any?): String =
        parts.joinToString("|") { it?.toString() ?: "" }

    fun split(line: String): List<String> = line.split("|")

    fun escape(text: String): String = text.replace("|", "¦").replace("\n", " ").trim()

    // ---------------------------------------------------------------- SNAPSHOT

    /**
     * SNAP alanları:
     * phase|localId|tasksDone|taskSlots|sabotageType|sabotageLeft|killCooldown|
     * emergencyUsable|ventAvailable|winner|myTasks|players|bodies|meeting
     */
    fun encodeSnapshot(s: GameSnapshot): String {
        val players = s.players.joinToString(";") { p ->
            listOf(
                p.id,
                p.colorIndex,
                when (p.role) {
                    Role.IMPOSTOR -> "I"
                    Role.CREWMATE -> "C"
                    null -> "?"
                },
                fmt(p.x),
                fmt(p.y),
                if (p.alive) 1 else 0,
                if (p.isBot) 1 else 0,
                if (p.connected) 1 else 0,
                p.tasksDone,
                p.taskTotal,
                if (p.inVent) 1 else 0,
            ).joinToString(":")
        }
        val bodies = s.bodies.joinToString(";") { b ->
            listOf(b.id, fmt(b.x), fmt(b.y), b.colorIndex, if (b.reported) 1 else 0).joinToString(":")
        }
        val meeting = s.meeting?.let { m ->
            val votes = m.votes.entries.joinToString(";") { (v, t) -> "$v:$t" }
            listOf(
                m.stage.name,
                m.reason.name,
                m.callerId,
                fmt(m.discussionLeft),
                fmt(m.votingLeft),
                votes,
                m.ejectedId,
                m.chat.size,
            ).joinToString(":")
        } ?: "-"
        return encode(
            s.phase.name,
            s.localPlayerId,
            s.globalTasksDone,
            s.totalTaskSlots,
            s.sabotage?.type?.name ?: "-",
            fmt(s.sabotage?.secondsLeft ?: -1f),
            fmt(s.killCooldown),
            if (s.emergencyUsable) 1 else 0,
            if (s.ventAvailable) 1 else 0,
            s.winner?.name ?: "-",
            s.completedTasks.joinToString(","),
            s.myTasks.joinToString(","),
            players,
            bodies,
            meeting,
        )
    }

    data class DecodedSnapshot(
        val phase: Phase,
        val localPlayerId: Int,
        val globalTasksDone: Int,
        val totalTaskSlots: Int,
        val sabotage: SabotageState?,
        val killCooldown: Float,
        val emergencyUsable: Boolean,
        val ventAvailable: Boolean,
        val winner: Winner?,
        val completedTasks: Set<Int>,
        val myTasks: List<Int>,
        val players: List<PlayerView>,
        val bodies: List<Body>,
        val meeting: Meeting?,
    )

    fun decodeSnapshot(payload: String): DecodedSnapshot? {
        val f = payload.split("|")
        if (f.size < 15) return null
        fun i(idx: Int) = f.getOrNull(idx)?.toIntOrNull() ?: 0
        fun fl(idx: Int) = f.getOrNull(idx)?.toFloatOrNull() ?: 0f

        val players = f.getOrNull(12)?.split(";")?.filter { it.isNotBlank() }?.mapNotNull { raw ->
            val p = raw.split(":")
            if (p.size < 11) return@mapNotNull null
            PlayerView(
                id = p[0].toIntOrNull() ?: return@mapNotNull null,
                name = "",
                colorIndex = p[1].toIntOrNull() ?: 0,
                role = when (p[2]) {
                    "I" -> Role.IMPOSTOR
                    "C" -> Role.CREWMATE
                    else -> null
                },
                x = p[3].toFloatOrNull() ?: 0f,
                y = p[4].toFloatOrNull() ?: 0f,
                alive = p[5] == "1",
                isBot = p[6] == "1",
                connected = p[7] == "1",
                tasksDone = p[8].toIntOrNull() ?: 0,
                taskTotal = p[9].toIntOrNull() ?: 0,
                inVent = p[10] == "1",
            )
        } ?: emptyList()

        val bodies = f.getOrNull(13)?.split(";")?.filter { it.isNotBlank() }?.mapNotNull { raw ->
            val b = raw.split(":")
            if (b.size < 5) return@mapNotNull null
            Body(
                id = b[0].toIntOrNull() ?: return@mapNotNull null,
                x = b[1].toFloatOrNull() ?: 0f,
                y = b[2].toFloatOrNull() ?: 0f,
                colorIndex = b[3].toIntOrNull() ?: 0,
                reported = b[4] == "1",
            )
        } ?: emptyList()

        val meetingRaw = f.getOrNull(14) ?: "-"
        var meeting: Meeting? = null
        if (meetingRaw != "-" && meetingRaw.isNotBlank()) {
            val m = meetingRaw.split(":")
            if (m.size >= 8) {
                val mm = Meeting(
                    reason = MeetingReason.entries.firstOrNull { it.name == m[1] } ?: MeetingReason.BUTTON,
                    callerId = m[2].toIntOrNull() ?: -1,
                    stage = MeetingStage.entries.firstOrNull { it.name == m[0] } ?: MeetingStage.DISCUSSION,
                    discussionLeft = m[3].toFloatOrNull() ?: 0f,
                    votingLeft = m[4].toFloatOrNull() ?: 0f,
                    ejectedId = m[6].toIntOrNull() ?: -1,
                )
                m[5].split(";").filter { it.isNotBlank() }.forEach { v ->
                    val parts = v.split(":")
                    if (parts.size == 2) {
                        mm.votes[parts[0].toIntOrNull() ?: return@forEach] = parts[1].toIntOrNull() ?: -1
                    }
                }
                meeting = mm
            }
        }

        val sabType = f.getOrNull(4) ?: "-"
        val sabLeft = fl(5)
        return DecodedSnapshot(
            phase = Phase.entries.firstOrNull { it.name == f[0] } ?: Phase.LOBBY,
            localPlayerId = i(1),
            globalTasksDone = i(2),
            totalTaskSlots = i(3),
            sabotage = if (sabType != "-" && sabType.isNotBlank()) {
                SabotageState(
                    SabotageType.entries.firstOrNull { it.name == (sabType ?: "") } ?: SabotageType.LIGHTS,
                    sabLeft,
                )
            } else null,
            killCooldown = fl(6),
            emergencyUsable = f.getOrNull(7) == "1",
            ventAvailable = f.getOrNull(8) == "1",
            winner = Winner.entries.firstOrNull { it.name == (f.getOrNull(9) ?: "") },
            completedTasks = f.getOrNull(10)?.split(",")?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet(),
            myTasks = f.getOrNull(11)?.split(",")?.mapNotNull { it.toIntOrNull() } ?: emptyList(),
            players = players,
            bodies = bodies,
            meeting = meeting,
        )
    }

    // ---------------------------------------------------------------- LOBBY

    fun encodeLobby(room: String, hostId: Int, players: List<Player>): String {
        val list = players.joinToString(";") { p ->
            listOf(p.id, escape(p.name), p.colorIndex, if (p.isBot) 1 else 0, if (p.connected) 1 else 0).joinToString(":")
        }
        return encode(LOBBY, room, hostId, list)
    }

    data class LobbyPlayer(val id: Int, val name: String, val colorIndex: Int, val isBot: Boolean, val connected: Boolean)

    fun decodeLobby(payload: String): Pair<String, List<LobbyPlayer>>? {
        val f = payload.split("|")
        if (f.size < 4) return null
        val list = f[3].split(";").filter { it.isNotBlank() }.mapNotNull { raw ->
            val p = raw.split(":")
            if (p.size < 5) return@mapNotNull null
            LobbyPlayer(
                id = p[0].toIntOrNull() ?: return@mapNotNull null,
                name = p[1],
                colorIndex = p[2].toIntOrNull() ?: 0,
                isBot = p[3] == "1",
                connected = p[4] == "1",
            )
        }
        return f[1] to list
    }

    fun fmt(v: Float): String {
        val r = Math.round(v * 10f) / 10f
        return if (r == r.toInt().toFloat()) r.toInt().toString() else r.toString()
    }
}
