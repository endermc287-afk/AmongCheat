package com.amongushile.game.ui.game

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.amongushile.core.Colors
import com.amongushile.core.GameSnapshot
import com.amongushile.core.Role
import com.amongushile.core.ShipMap
import com.amongushile.core.Vec2
import kotlin.math.hypot
import kotlin.math.min

/** Gemi haritasını, oyuncuları ve görev istasyonlarını çizer. */
@Composable
fun GameCanvas(
    snapshot: GameSnapshot,
    modifier: Modifier = Modifier,
) {
    val map = ShipMap.STANDARD
    val measurer = androidx.compose.ui.text.rememberTextMeasurer()
    Canvas(modifier = modifier) {
        val scale = min(size.width / map.width, size.height / map.height)
        val ox = (size.width - map.width * scale) / 2f
        val oy = (size.height - map.height * scale) / 2f

        fun tx(v: Float) = ox + v * scale
        fun ty(v: Float) = oy + v * scale

        // Arka plan
        drawRect(Color(0xFF05070D))

        // Odalar
        map.rooms.forEach { room ->
            val topLeft = Offset(tx(room.rect.x), ty(room.rect.y))
            val rSize = Size(room.rect.w * scale, room.rect.h * scale)
            drawRoundRect(
                color = Color(room.color),
                topLeft = topLeft,
                size = rSize,
                cornerRadius = CornerRadius(14f * scale, 14f * scale),
            )
            drawRoundRect(
                color = Color.White.copy(alpha = 0.10f),
                topLeft = topLeft,
                size = rSize,
                cornerRadius = CornerRadius(14f * scale, 14f * scale),
                style = Stroke(width = 2f),
            )
            drawText(
                measurer,
                text = room.name,
                topLeft = Offset(tx(room.rect.x) + 10f, ty(room.rect.y) + 8f),
                style = TextStyle(color = Color.White.copy(alpha = 0.30f), fontSize = 11.sp),
            )
        }

        // Görev istasyonları
        snapshot.tasks.forEach { station ->
            val done = snapshot.completedTasks.contains(station.id)
            val c = if (done) Color(0xFF3FE07A) else Color(0xFFFFC94D)
            val r = 11f * scale
            drawCircle(
                color = c.copy(alpha = if (done) 0.55f else 0.95f),
                radius = r,
                center = Offset(tx(station.pos.x), ty(station.pos.y)),
            )
            drawCircle(
                color = Color.Black.copy(alpha = 0.55f),
                radius = r,
                center = Offset(tx(station.pos.x), ty(station.pos.y)),
                style = Stroke(width = 2f),
            )
            drawText(
                measurer,
                text = station.title,
                topLeft = Offset(tx(station.pos.x) + r + 3f, ty(station.pos.y) - 8f),
                style = TextStyle(color = c.copy(alpha = 0.85f), fontSize = 9.sp),
            )
        }

        // Havalandırmalar
        map.vents.forEach { vent ->
            drawRect(
                color = Color(0xFF3FA7FF).copy(alpha = 0.35f),
                topLeft = Offset(tx(vent.pos.x) - 9f * scale, ty(vent.pos.y) - 9f * scale),
                size = Size(18f * scale, 18f * scale),
            )
        }

        // Cesetler
        snapshot.bodies.forEach { body ->
            drawBody(
                center = Offset(tx(body.x), ty(body.y)),
                size = 26f * scale,
                color = Color(Colors.color(body.colorIndex)),
                measurer = measurer,
            )
        }

        // Oyuncular
        val local = snapshot.players.firstOrNull { it.id == snapshot.localPlayerId }
        snapshot.players.forEach { player ->
            val pos = Offset(tx(player.x), ty(player.y))
            if (snapshot.cheats.playerEsp && local != null && player.id != local.id) {
                val sameRoom = map.roomAt(Vec2(player.x, player.y))?.name ==
                    map.roomAt(Vec2(local.x, local.y))?.name
                if (!sameRoom) {
                    // Duvar arkasındakileri işaretle
                    drawCircle(
                        color = Color(0xFFFF5B5B).copy(alpha = 0.35f),
                        radius = 16f * scale,
                        center = pos,
                    )
                    val d = hypot(player.x - local.x, player.y - local.y).toInt()
                    drawText(
                measurer,
                text = "$d m",
                        topLeft = Offset(pos.x + 10f * scale, pos.y - 22f * scale),
                        style = TextStyle(color = Color(0xFFFF5B5B), fontSize = 10.sp, fontWeight = FontWeight.Bold),
                            )
                }
            }
            drawCrewmate(
                center = pos,
                size = 26f * scale,
                color = Color(Colors.color(player.colorIndex)),
                isSelf = player.id == snapshot.localPlayerId,
                isGhost = !player.alive,
                role = player.role,
                measurer = measurer,
            )
            if (player.role != null && snapshot.cheats.revealRoles) {
                drawText(
                measurer,
                text = if (player.role == Role.IMPOSTOR) "HİLECİ" else "MÜRETTEBAT",
                    topLeft = Offset(pos.x - 22f * scale, pos.y + 18f * scale),
                    style = TextStyle(
                        color = if (player.role == Role.IMPOSTOR) Color(0xFFFF5B5B) else Color(0xFF3FE07A),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                    ),
                    )
            }
        }
    }
}

private fun DrawScope.drawCrewmate(
    center: Offset,
    size: Float,
    color: Color,
    isSelf: Boolean,
    isGhost: Boolean,
    role: Role?,
    measurer: TextMeasurer,
) {
    val alpha = if (isGhost) 0.45f else 1f
    val half = size / 2f

    if (isSelf) {
        drawCircle(color = Color.White.copy(alpha = 0.25f), radius = half * 1.5f, center = center)
    }

    // gövde
    drawRoundRect(
        color = color.copy(alpha = alpha),
        topLeft = Offset(center.x - half, center.y - half * 0.95f),
        size = Size(size, size * 0.95f),
        cornerRadius = CornerRadius(size * 0.32f, size * 0.32f),
    )
    // sırt
    drawRoundRect(
        color = color.copy(alpha = alpha * 0.75f),
        topLeft = Offset(center.x - half * 1.25f, center.y - half * 0.45f),
        size = Size(size * 0.32f, size * 0.5f),
        cornerRadius = CornerRadius(size * 0.12f, size * 0.12f),
    )
    // vizör
    drawRoundRect(
        color = Color(0xFFCFE9FF).copy(alpha = alpha),
        topLeft = Offset(center.x - half * 0.55f, center.y - half * 0.72f),
        size = Size(size * 0.85f, size * 0.42f),
        cornerRadius = CornerRadius(size * 0.18f, size * 0.18f),
    )
    // bacaklar
    drawRoundRect(
        color = color.copy(alpha = alpha * 0.8f),
        topLeft = Offset(center.x - half * 0.62f, center.y + half * 0.92f),
        size = Size(size * 0.34f, size * 0.34f),
        cornerRadius = CornerRadius(size * 0.12f, size * 0.12f),
    )
    drawRoundRect(
        color = color.copy(alpha = alpha * 0.8f),
        topLeft = Offset(center.x + half * 0.28f, center.y + half * 0.92f),
        size = Size(size * 0.34f, size * 0.34f),
        cornerRadius = CornerRadius(size * 0.12f, size * 0.12f),
    )
    // hileci rozeti
    if (role == Role.IMPOSTOR) {
        drawCircle(
            color = Color(0xFFFF5B5B).copy(alpha = 0.9f),
            radius = size * 0.12f,
            center = Offset(center.x + half * 0.8f, center.y - half * 0.9f),
        )
    }
}

private fun DrawScope.drawBody(
    center: Offset,
    size: Float,
    color: Color,
    measurer: TextMeasurer,
) {
    rotate(-25f, center) {
        drawRoundRect(
            color = color.copy(alpha = 0.75f),
            topLeft = Offset(center.x - size / 2f, center.y - size / 2f),
            size = Size(size, size),
            cornerRadius = CornerRadius(size * 0.3f, size * 0.3f),
        )
        drawRoundRect(
            color = Color(0xFFCFE9FF).copy(alpha = 0.6f),
            topLeft = Offset(center.x - size * 0.2f, center.y - size * 0.34f),
            size = Size(size * 0.7f, size * 0.3f),
            cornerRadius = CornerRadius(size * 0.12f, size * 0.12f),
        )
    }
}
