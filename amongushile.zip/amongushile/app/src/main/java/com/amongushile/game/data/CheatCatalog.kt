package com.amongushile.game.data

/** Hile menüsü kataloğu: hem tam ekran menü hem yüzer menü aynı listeyi kullanır. */
enum class CheatType { TOGGLE, ACTION, SLIDER }

data class CheatDef(
    val key: String,
    val title: String,
    val desc: String,
    val type: CheatType,
    val note: String = "",
)

object CheatCatalog {
    val items = listOf(
        CheatDef(
            "alwaysImpostor", "Her Zaman Hileci",
            "Rol atamasında seni hileci yapar (sunucu tarafında uygulanır).",
            CheatType.TOGGLE, "Kendi sunucun ve antrenmanda etkili",
        ),
        CheatDef(
            "revealRoles", "İmposter Bulucu",
            "Tüm oyuncuların gerçek rolünü canlı gösterir.",
            CheatType.TOGGLE, "Kendi sunucun ve antrenmanda etkili",
        ),
        CheatDef(
            "playerEsp", "Player ESP",
            "Oyuncuları duvar arkasından görünür kılar, mesafeyi yazar.",
            CheatType.TOGGLE, "Kendi sunucun ve antrenmanda etkili",
        ),
        CheatDef(
            "speed", "Hız Hack",
            "Hareket hızını 1x - 4x arasında artırır.",
            CheatType.SLIDER, "Kendi sunucun ve antrenmanda etkili",
        ),
        CheatDef(
            "killAll", "Kill All",
            "Bütün mürettebatları tek dokunuşla öldürür.",
            CheatType.ACTION, "Sunucu yetkisi gerekir (kendi host'un)",
        ),
        CheatDef(
            "kickAll", "Kick All",
            "Lobideki bütün oyuncuları dışarı atar.",
            CheatType.ACTION, "Sunucu yetkisi gerekir (kendi host'un)",
        ),
        CheatDef(
            "instantTasks", "Anında Görevler",
            "Görevler tek dokunuşta tamamlanır.",
            CheatType.TOGGLE, "Kendi sunucun ve antrenmanda etkili",
        ),
        CheatDef(
            "skipKillCooldown", "Beklemesiz Öldürme",
            "Öldürme bekleme süresini kaldırır.",
            CheatType.TOGGLE, "Kendi sunucun ve antrenmanda etkili",
        ),
        CheatDef(
            "noMeetings", "Toplantıları Kapat",
            "Acil toplantı ve oylama devre dışı kalır.",
            CheatType.TOGGLE, "Kendi sunucun ve antrenmanda etkili",
        ),
        CheatDef(
            "ghostMode", "Hayalet Modu",
            "Öldükten sonra da gezebilirsin.",
            CheatType.TOGGLE, "Kendi sunucun ve antrenmanda etkili",
        ),
        CheatDef(
            "freeCamera", "Serbest Kamera",
            "Kamera sınırlarını kaldırır.",
            CheatType.TOGGLE, "Kendi sunucun ve antrenmanda etkili",
        ),
        CheatDef(
            "unlockSkins", "Tüm Skinler",
            "Bütün kostümler açılır.",
            CheatType.TOGGLE, "Kendi sunucun ve antrenmanda etkili",
        ),
        CheatDef(
            "impostorCount", "Hileci Sayısı",
            "Lobideki hileci sayısını 1 - 4 arasında ayarlar.",
            CheatType.SLIDER, "Kendi sunucun ve antrenmanda etkili",
        ),
    )

    /** Gerçek Among Us istemcisinin belleğine müdahale etmeyen, root'suz hileler. */
    val rootlessItems = listOf(
        CheatDef(
            "launchGame", "Among Us'u Aç",
            "Among Us'u bulur ve açar.",
            CheatType.ACTION, "Gerçek Among Us üzerinde çalışır",
        ),
        CheatDef(
            "autoTask", "Otomatik Görev",
            "Görev ekranındaki onay düğmelerine otomatik dokunur.",
            CheatType.TOGGLE, "Gerçek Among Us üzerinde çalışır (erişilebilirlik izni)",
        ),
        CheatDef(
            "autoReport", "Otomatik Bildir",
            "Ceset bulunduğunda bildir düğmesine dokunur.",
            CheatType.TOGGLE, "Gerçek Among Us üzerinde çalışır (erişilebilirlik izni)",
        ),
    )
}
