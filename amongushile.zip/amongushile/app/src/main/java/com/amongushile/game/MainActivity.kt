package com.amongushile.game

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.amongushile.game.data.HileDurumu
import com.amongushile.game.game.GameSource
import com.amongushile.game.game.LocalGameSource
import com.amongushile.game.launch.AmongUsLauncher
import com.amongushile.game.net.OnlineSession
import com.amongushile.game.overlay.OverlayService
import com.amongushile.game.ui.screens.CheatMenuScreen
import com.amongushile.game.ui.screens.GameScreen
import com.amongushile.game.ui.screens.HomeScreen
import com.amongushile.game.ui.screens.OnlineScreen
import com.amongushile.game.ui.theme.AmongUsHileTheme

class MainActivity : ComponentActivity() {

    internal val uiTick = mutableIntStateOf(0)

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        HileDurumu.init(this)
        // Hile değişiklikleri aktif online oturuma anında gönderilir (her odada geçerli)
        HileDurumu.addListener { _, _ ->
            OnlineSession.current?.pushCheats(HileDurumu.cheats)
        }
        requestNotificationPermissionIfNeeded()

        setContent {
            AmongUsHileTheme {
                AppRoot()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        uiTick.intValue++
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            try {
                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } catch (ignored: Exception) {
            }
        }
    }
}

private enum class Screen { HOME, CHEATS, ONLINE, PRACTICE }

@Composable
fun AppRoot() {
    val context = LocalContext.current
    var screen by remember { mutableStateOf(Screen.HOME) }
    var amongUsPackage by remember { mutableStateOf<String?>(null) }
    var overlayAllowed by remember { mutableStateOf(false) }
    var overlayRunning by remember { mutableStateOf(false) }
    var accessibilityOn by remember { mutableStateOf(false) }
    var practiceSource by remember { mutableStateOf<GameSource?>(null) }
    val scope = rememberCoroutineScope()

    // onResume'da durumları tazele
    val tick = uiTickRead(context)

    amongUsPackage = AmongUsLauncher.installedPackage(context)
    overlayAllowed = Settings.canDrawOverlays(context)
    overlayRunning = HileDurumu.overlayEnabled
    accessibilityOn = AmongUsLauncher.isAccessibilityServiceEnabled(context)

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    fun launchAmongUs() {
        when (AmongUsLauncher.launch(context)) {
            com.amongushile.game.launch.LaunchResult.LAUNCHED -> toast("Among Us açılıyor")
            com.amongushile.game.launch.LaunchResult.NOT_INSTALLED ->
                toast("Among Us kurulu değil - Play Store açılıyor")
            com.amongushile.game.launch.LaunchResult.FAILED -> toast("Among Us açılamadı")
        }
    }

    fun setOverlay(on: Boolean) {
        if (on) {
            if (!Settings.canDrawOverlays(context)) {
                try {
                    context.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}"),
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    context.startActivity(
                        Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
                return
            }
            try {
                ContextCompat.startForegroundService(context, Intent(context, OverlayService::class.java))
                HileDurumu.overlayEnabled = true
                overlayRunning = true
                toast("Yüzer menü açıldı")
            } catch (e: Exception) {
                toast("Yüzer menü açılamadı: ${e.message}")
            }
        } else {
            try {
                context.stopService(Intent(context, OverlayService::class.java))
            } catch (ignored: Exception) {
            }
            HileDurumu.overlayEnabled = false
            overlayRunning = false
            toast("Yüzer menü kapatıldı")
        }
    }

    fun openAccessibilitySettings() {
        try {
            context.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            toast("Erişilebilirlik ayarları açılamadı")
        }
    }

    val handleAction: (String) -> Unit = { key ->
        when (key) {
            "launchGame" -> launchAmongUs()
            "killAll", "kickAll" -> {
                val online = OnlineSession.current
                if (online != null) {
                    online.applyCheatAction(key)
                    toast("Hile sunucuya gönderildi: $key")
                } else {
                    toast("Bu hile için çevrimiçi lobiye bağlan")
                }
            }
            else -> Unit
        }
    }

    when (screen) {
        Screen.HOME -> HomeScreen(
            amongUsPackage = amongUsPackage,
            overlayAllowed = overlayAllowed,
            overlayRunning = overlayRunning,
            accessibilityOn = accessibilityOn,
            activeCheats = HileDurumu.cheats.activeCount,
            onLaunchGame = { launchAmongUs() },
            onOverlayToggle = { setOverlay(it) },
            onAccessibilityClick = { openAccessibilitySettings() },
            onOpenCheats = { screen = Screen.CHEATS },
            onPractice = {
                practiceSource = LocalGameSource(
                    name = HileDurumu.playerName.ifBlank { "Sen" },
                    colorIndex = 0,
                )
                screen = Screen.PRACTICE
            },
            onOnline = { screen = Screen.ONLINE },
        )

        Screen.CHEATS -> CheatMenuScreen(
            onBack = { screen = Screen.HOME },
            onAction = handleAction,
        )

        Screen.ONLINE -> OnlineScreen(onExit = { screen = Screen.HOME })

        Screen.PRACTICE -> {
            val source = practiceSource
            if (source == null) {
                screen = Screen.HOME
            } else {
                androidx.compose.runtime.LaunchedEffect(source) {
                    (source as? LocalGameSource)?.start(scope)
                }
                GameScreen(
                    source = source,
                    onExit = {
                        source.dispose()
                        practiceSource = null
                        screen = Screen.HOME
                    },
                )
            }
        }
    }
}

/** onResume sayacını okuyup yeniden çizim tetikler. */
@Composable
private fun uiTickRead(context: android.content.Context): Int {
    val activity = context as? MainActivity
    val tick by (activity?.uiTick ?: mutableIntStateOf(0))
    return tick
}
