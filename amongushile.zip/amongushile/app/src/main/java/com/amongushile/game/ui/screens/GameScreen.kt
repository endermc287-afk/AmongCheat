package com.amongushile.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amongushile.core.ChatMessage
import com.amongushile.core.Role
import com.amongushile.core.SabotageType
import com.amongushile.core.TaskStation
import com.amongushile.game.data.HileDurumu
import com.amongushile.game.game.GameEvent
import com.amongushile.game.game.GameSource
import com.amongushile.game.ui.game.GameCanvas
import com.amongushile.game.ui.game.Joystick
import com.amongushile.game.ui.game.MeetingView
import com.amongushile.game.ui.game.TaskMinigame
import com.amongushile.game.ui.theme.Gri
import com.amongushile.game.ui.theme.Kirmizi
import com.amongushile.game.ui.theme.Mavi
import com.amongushile.game.ui.theme.Panel
import com.amongushile.game.ui.theme.Sari
import com.amongushile.game.ui.theme.Yesil

/** Oyun ekranı: harita, HUD, kontroller, görevler ve toplantı. */
@Composable
fun GameScreen(
    source: GameSource,
    onExit: () -> Unit,
) {
    val snapshot by source.snapshot.collectAsState()
    var chat by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var activeTask by remember { mutableStateOf<TaskStation?>(null) }
    var showTaskList by remember { mutableStateOf(false) }
    var showCheats by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var showSabotage by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        source.chat.collect { msg -> chat = (chat + msg).takeLast(120) }
    }
    LaunchedEffect(Unit) {
        source.events.collect { event ->
            when (event) {
                is GameEvent.OpenTask -> activeTask = event.station
                is GameEvent.Notice -> notice = event.text
                is GameEvent.Vent -> notice = "Havalandırmada - bir sonraki çıkışı seç"
            }
        }
    }

    val me = snapshot.players.firstOrNull { it.id == snapshot.localPlayerId }
    val isImpostor = me?.role == Role.IMPOSTOR
    val myDone = snapshot.completedTasks.size
    val myTotal = snapshot.myTasks.size

    Box(Modifier.fillMaxSize().background(Color(0xFF05070D))) {
        GameCanvas(snapshot, Modifier.fillMaxSize())

        // ------------------------------------------------ üst bar
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Tag(
                    text = if (isImpostor) "HİLECİ" else "MÜRETTEBAT",
                    color = if (isImpostor) Kirmizi else Yesil,
                )
                Spacer(Modifier.width(6.dp))
                Tag(text = "Görev $myDone/$myTotal", color = Mavi)
                if (snapshot.cheats.activeCount > 0) {
                    Spacer(Modifier.width(6.dp))
                    Tag(text = "HİLE ${snapshot.cheats.activeCount}", color = Sari)
                }
            }
            Spacer(Modifier.height(6.dp))
            snapshot.sabotage?.let { sab ->
                Tag(text = "${sab.type.labelTr} ${sab.secondsLeft.toInt()}s", color = Kirmizi)
            }
            if (isImpostor && snapshot.killCooldown > 0f) {
                Spacer(Modifier.height(4.dp))
                Tag(text = "Öldürme bekleme ${snapshot.killCooldown.toInt()}s", color = Sari)
            }
        }

        // ------------------------------------------------ sağ üst butonlar
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            SmallButton("HİLE") { showCheats = !showCheats }
            SmallButton("GÖREV") { showTaskList = !showTaskList }
            SmallButton("ÇIKIŞ") { onExit() }
        }

        // ------------------------------------------------ görev listesi
        if (showTaskList) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 70.dp, start = 16.dp, end = 16.dp)
                    .background(Panel, RoundedCornerShape(14.dp))
                    .border(1.dp, Mavi.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                    .padding(14.dp),
            ) {
                Column {
                    Text("Görevlerim", color = Mavi, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    snapshot.tasks.filter { snapshot.myTasks.contains(it.id) }.forEach { st ->
                        val done = snapshot.completedTasks.contains(st.id)
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(if (done) Yesil else Sari, RoundedCornerShape(5.dp))
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "${st.title} (${st.room})",
                                color = if (done) Gri else Color.White,
                                fontSize = 13.sp,
                            )
                        }
                    }
                }
            }
        }

        // ------------------------------------------------ hile paneli
        if (showCheats) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxWidth(0.92f)
                    .padding(end = 8.dp)
                    .background(Color(0xF20B0E17), RoundedCornerShape(14.dp))
                    .border(1.dp, Mavi.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
            ) {
                CheatMenuContent(
                    onAction = { key -> source.cheatAction(key) },
                    showRootless = false,
                    modifier = Modifier.height(460.dp),
                )
            }
        }

        // ------------------------------------------------ alt kontroller
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            Joystick(modifier = Modifier.size(140.dp)) { dx, dy -> source.move(dx, dy) }

            Spacer(Modifier.weight(1f))

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (isImpostor) {
                    ActionButton(
                        text = "SABOTAJ",
                        color = Kirmizi,
                        enabled = snapshot.sabotage == null,
                    ) { showSabotage = !showSabotage }
                    ActionButton(
                        text = "ÖLDÜR",
                        color = Kirmizi,
                        enabled = snapshot.killCooldown <= 0f,
                    ) { source.kill() }
                }
                ActionButton(text = "TOPLANTI", color = Color(0xFF2C3854), enabled = snapshot.emergencyUsable) {
                    source.emergency()
                }
                ActionButton(text = "KULLAN", color = Mavi) { source.use() }
            }
        }

        // ------------------------------------------------ sabotaj seçimi
        if (showSabotage) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Panel, RoundedCornerShape(14.dp))
                    .padding(14.dp),
            ) {
                Column {
                    Text("Sabotaj seç", color = Mavi, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    SabotageType.entries.forEach { type ->
                        Row(
                            modifier = Modifier
                                .clickable {
                                    source.sabotage(type)
                                    showSabotage = false
                                }
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                        ) {
                            Text(type.labelTr, color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        // ------------------------------------------------ bildirim
        notice?.let {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 60.dp)
                    .background(Color(0xEE1F2740), RoundedCornerShape(10.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .clickable { notice = null },
            ) {
                Text(it, color = Color.White, fontSize = 13.sp)
            }
        }

        // ------------------------------------------------ görev minigamesi
        activeTask?.let { station ->
            TaskMinigame(
                station = station,
                instant = snapshot.cheats.instantTasks,
                onComplete = {
                    source.completeTask(station.id)
                    activeTask = null
                },
                onClose = { activeTask = null },
            )
        }

        // ------------------------------------------------ toplantı
        if (snapshot.meeting != null && activeTask == null) {
            MeetingView(
                snapshot = snapshot,
                chat = chat,
                onVote = { source.vote(it) },
                onSay = { source.say(it) },
                onLeave = { },
            )
        }

        // ------------------------------------------------ oyun sonu
        snapshot.winner?.let { winner ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xEE05070D)),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (winner == com.amongushile.core.Winner.CREWMATES) "MÜRETTEBAT KAZANDI" else "HİLECİLER KAZANDI",
                        color = if (winner == com.amongushile.core.Winner.CREWMATES) Yesil else Kirmizi,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = onExit,
                        colors = ButtonDefaults.buttonColors(containerColor = Mavi),
                    ) { Text("Ana Menü") }
                }
            }
        }
    }
}

@Composable
private fun Tag(text: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.18f), RoundedCornerShape(8.dp))
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
    ) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SmallButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(Color(0xCC1F2740), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 7.dp),
    ) {
        Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ActionButton(
    text: String,
    color: Color,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = if (enabled) 0.85f else 0.25f), RoundedCornerShape(16.dp))
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 18.dp, vertical = 12.dp),
    ) {
        Text(
            text = text,
            color = if (enabled) Color.White else Color(0xFF8892A6),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}
