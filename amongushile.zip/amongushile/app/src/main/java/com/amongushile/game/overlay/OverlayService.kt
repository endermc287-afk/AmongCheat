package com.amongushile.game.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.amongushile.game.MainActivity
import com.amongushile.game.data.CheatCatalog
import com.amongushile.game.data.CheatType
import com.amongushile.game.data.HileDurumu
import com.amongushile.game.launch.AmongUsLauncher
import com.amongushile.game.launch.LaunchResult

/**
 * Yüzer (floating) menü servisi.
 * Başka uygulamaların - gerçek Among Us dahil - üzerine çizilir.
 * SYSTEM_ALERT_WINDOW izni ile çalışır, root gerektirmez.
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        HileDurumu.init(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        attachBubble()
        return START_STICKY
    }

    override fun onDestroy() {
        removePanel()
        removeBubble()
        super.onDestroy()
    }

    // ------------------------------------------------------------ foreground

    private fun startForegroundCompat() {
        val channelId = "overlay_menu"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Yüzer Menü",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Among Us üzerinde yüzer menü"
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)
        }

        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        val notification = builder
            .setContentTitle("Among Us Hilesi")
            .setContentText("Yüzer menü açık - oyuna dönmek için dokun")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            // İzin yoksa sessizce geç
        }
    }

    // ------------------------------------------------------------ yüzer balon

    private fun attachBubble() {
        if (bubbleView != null) return
        val size = dp(58)
        val view = CrewmateBadgeView(this)
        val params = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(150)
        }

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downRawX).toInt()
                    params.y = startY + (event.rawY - downRawY).toInt()
                    try {
                        windowManager.updateViewLayout(v, params)
                    } catch (ignored: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = kotlin.math.abs(event.rawX - downRawX) > 12 ||
                        kotlin.math.abs(event.rawY - downRawY) > 12
                    if (!moved) togglePanel()
                    true
                }
                else -> true
            }
        }

        try {
            windowManager.addView(view, params)
            bubbleView = view
            bubbleParams = params
        } catch (e: Exception) {
            Toast.makeText(this, "Yüzer menü açılamadı: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0

    private fun removeBubble() {
        bubbleView?.let { try { windowManager.removeView(it) } catch (ignored: Exception) {} }
        bubbleView = null
    }

    // ------------------------------------------------------------ panel

    private fun togglePanel() {
        if (panelView != null) {
            removePanel()
        } else {
            showPanel()
        }
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackground(
                GradientDrawable().apply {
                    setColor(Color.argb(235, 12, 16, 28))
                    cornerRadius = dp(18).toFloat()
                    setStroke(dp(1), Color.argb(140, 80, 200, 255))
                }
            )
        }

        // Başlık
        root.addView(
            TextView(this).apply {
                text = "AMONG US HİLESİ"
                setTextColor(Color.parseColor("#59D0FF"))
                textSize = 15f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, 0, 0, dp(6))
            }
        )

        // Durum
        val status = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#C7D2E4"))
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(status)

        // Kaydırılabilir hile listesi
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            )
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Gerçek Among Us üzerinde çalışan root'suz hile/hile yardımcıları
        list.addView(sectionLabel("GERÇEK AMONG US ÜZERİNDE"))
        CheatCatalog.rootlessItems.forEach { def ->
            when (def.type) {
                CheatType.ACTION -> list.addView(
                    actionButton(def.title) {
                        when (def.key) {
                            "launchGame" -> {
                                val r = AmongUsLauncher.launch(this@OverlayService)
                                if (r == LaunchResult.NOT_INSTALLED) {
                                    toast("Among Us kurulu değil - Play Store açılıyor")
                                } else if (r == LaunchResult.LAUNCHED) {
                                    toast("Among Us açılıyor")
                                } else {
                                    toast("Among Us açılamadı")
                                }
                            }
                        }
                    }
                )
                CheatType.TOGGLE -> list.addView(
                    switchRow(def.title, def.desc, def.key, HileDurumu.isOn(def.key)) { on ->
                        HileDurumu.toggle(def.key, on)
                        status.text = statusText()
                    }
                )
                CheatType.SLIDER -> Unit
            }
        }

        list.addView(sectionLabel("SUNUCU / ANTRENMAN HİLELERİ"))
        CheatCatalog.items.forEach { def ->
            when (def.type) {
                CheatType.TOGGLE -> list.addView(
                    switchRow(def.title, def.desc, def.key, HileDurumu.isOn(def.key)) { on ->
                        HileDurumu.toggle(def.key, on)
                        status.text = statusText()
                    }
                )
                CheatType.ACTION -> list.addView(
                    actionButton(def.title) {
                        com.amongushile.game.net.OnlineSession.current?.applyCheatAction(def.key)
                            ?: toast("Önce çevrimiçi lobiye bağlan")
                    }
                )
                CheatType.SLIDER -> {
                    if (def.key == "speed") {
                        list.addView(
                            switchRow("2x Hız", "Yürüme hızını iki katına çıkarır", "speed", HileDurumu.speed() > 1.01f) { on ->
                                HileDurumu.toggle("speed", on)
                                status.text = statusText()
                            }
                        )
                    } else {
                        list.addView(
                            switchRow("2 Hileci", "Lobide 2 hileci olur", "impostorCount", HileDurumu.impostorCount() > 1) { on ->
                                HileDurumu.toggle("impostorCount", on)
                                status.text = statusText()
                            }
                        )
                    }
                }
            }
        }

        scroll.addView(list)
        root.addView(scroll)

        // Alt butonlar
        root.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(10), 0, 0)
                addView(
                    Button(this@OverlayService).apply {
                        text = "Tam Menü"
                        textSize = 12f
                        setOnClickListener { openApp() }
                    },
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f),
                )
                addView(
                    Button(this@OverlayService).apply {
                        text = "Kapat"
                        textSize = 12f
                        setOnClickListener {
                            HileDurumu.overlayEnabled = false
                            stopSelf()
                        }
                    },
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f),
                )
            }
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(220)
        }

        try {
            windowManager.addView(root, params)
            panelView = root
            panelParams = params
            status.text = statusText()
        } catch (e: Exception) {
            toast("Panel açılamadı: ${e.message}")
        }
    }

    private fun removePanel() {
        panelView?.let { try { windowManager.removeView(it) } catch (ignored: Exception) {} }
        panelView = null
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(Color.parseColor("#8FA3BF"))
        setPadding(0, dp(10), 0, dp(2))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun switchRow(
        title: String,
        desc: String,
        key: String,
        checked: Boolean,
        onChange: (Boolean) -> Unit,
    ): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val label = TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val sw = Switch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, isChecked -> onChange(isChecked) }
            tag = key
        }
        line.addView(label)
        line.addView(sw)
        row.addView(line)
        row.addView(
            TextView(this).apply {
                text = desc
                textSize = 10f
                setTextColor(Color.parseColor("#8FA3BF"))
            }
        )
        return row
    }

    private fun actionButton(title: String, onClick: () -> Unit): View = Button(this).apply {
        text = title
        textSize = 12f
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        )
    }

    private fun statusText(): String {
        val pkg = AmongUsLauncher.installedPackage(this)
        val game = if (pkg != null) "Among Us kurulu ✓" else "Among Us bulunamadı ✕"
        return "$game • Aktif hile: ${HileDurumu.cheats.activeCount}"
    }

    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try {
            startActivity(intent)
        } catch (ignored: Exception) {
        }
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics
    ).toInt()

    companion object {
        private const val NOTIFICATION_ID = 4711
    }
}
