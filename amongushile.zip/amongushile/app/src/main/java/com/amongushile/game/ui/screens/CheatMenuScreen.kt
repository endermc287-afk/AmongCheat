package com.amongushile.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amongushile.game.data.CheatCatalog
import com.amongushile.game.data.CheatType
import com.amongushile.game.data.HileDurumu
import com.amongushile.game.ui.theme.Gri
import com.amongushile.game.ui.theme.Kirmizi
import com.amongushile.game.ui.theme.Mavi
import com.amongushile.game.ui.theme.Panel
import com.amongushile.game.ui.theme.Yesil

/** Hile menüsü içeriği (tam ekran ve oyun içi yüzer panel aynı bileşeni kullanır). */
@Composable
fun CheatMenuContent(
    onAction: (String) -> Unit,
    modifier: Modifier = Modifier,
    showRootless: Boolean = true,
) {
    var cheats by remember { mutableStateOf(HileDurumu.cheats) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        if (showRootless) {
            SectionTitle("GERÇEK AMONG US ÜZERİNDE (root'suz)")
            CheatCatalog.rootlessItems.forEach { def ->
                when (def.type) {
                    CheatType.ACTION -> ActionRow(def.title, def.desc, def.note) { onAction(def.key) }
                    CheatType.TOGGLE -> ToggleRow(
                        title = def.title,
                        desc = def.desc,
                        note = def.note,
                        checked = when (def.key) {
                            "autoTask" -> HileDurumu.autoTaskEnabled
                            "autoReport" -> HileDurumu.autoReportEnabled
                            else -> false
                        },
                    ) { on ->
                        when (def.key) {
                            "autoTask" -> HileDurumu.autoTaskEnabled = on
                            "autoReport" -> HileDurumu.autoReportEnabled = on
                        }
                    }
                    CheatType.SLIDER -> Unit
                }
            }
        }

        SectionTitle("HİLELERİN (sunucu + antrenman)")

        CheatCatalog.items.forEach { def ->
            when (def.type) {
                CheatType.TOGGLE -> ToggleRow(
                    title = def.title,
                    desc = def.desc,
                    note = def.note,
                    checked = HileDurumu.isOn(def.key),
                ) { on ->
                    HileDurumu.toggle(def.key, on)
                    cheats = HileDurumu.cheats
                }
                CheatType.ACTION -> ActionRow(def.title, def.desc, def.note) { onAction(def.key) }
                CheatType.SLIDER -> {
                    if (def.key == "speed") {
                        SpeedRow(
                            title = def.title,
                            desc = def.desc,
                            value = HileDurumu.speed(),
                            onChange = {
                                HileDurumu.setSpeed(it)
                                cheats = HileDurumu.cheats
                            },
                        )
                    } else {
                        ImpostorCountRow(
                            title = def.title,
                            desc = def.desc,
                            value = HileDurumu.impostorCount(),
                            onChange = {
                                HileDurumu.setImpostorCount(it)
                                cheats = HileDurumu.cheats
                            },
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            text = "Aktif hile: ${cheats.activeCount}",
            color = Mavi,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = "Not: Gerçek Among Us'un belleğine müdahale etmek root gerektirir. " +
                "Bu uygulama root'suz çalışır; rol atama gibi hile yetkileri kendi sunucun " +
                "ve antrenman modunda sunucu tarafında uygulanır.",
            color = Gri,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        color = Mavi,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp),
    )
}

@Composable
private fun ToggleRow(
    title: String,
    desc: String,
    note: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(desc, color = Gri, fontSize = 11.sp)
            if (note.isNotBlank()) Text(note, color = Color(0xFF59D0FF).copy(alpha = 0.75f), fontSize = 10.sp)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun ActionRow(title: String, desc: String, note: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(12.dp),
    ) {
        Text(title, color = Yesil, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text(desc, color = Gri, fontSize = 11.sp)
        if (note.isNotBlank()) Text(note, color = Color(0xFF59D0FF).copy(alpha = 0.75f), fontSize = 10.sp)
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun SpeedRow(
    title: String,
    desc: String,
    value: Float,
    onChange: (Float) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(12.dp))
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(desc, color = Gri, fontSize = 11.sp)
            }
            Text("${value}x", color = Mavi, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(1f, 2f, 3f, 4f).forEach { mult ->
                Button(
                    onClick = { onChange(mult) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (value == mult) Mavi else Color(0xFF2C3854)
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                ) { Text("${mult}x", fontSize = 12.sp) }
            }
        }
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun ImpostorCountRow(
    title: String,
    desc: String,
    value: Int,
    onChange: (Int) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(12.dp))
            .padding(12.dp),
    ) {
        Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text(desc, color = Gri, fontSize = 11.sp)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (1..4).forEach { n ->
                Button(
                    onClick = { onChange(n) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (value == n) Kirmizi else Color(0xFF2C3854)
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                ) { Text("$n", fontSize = 12.sp) }
            }
        }
    }
    Spacer(Modifier.height(6.dp))
}

/** Tam ekran hile menüsü sayfası. */
@Composable
fun CheatMenuScreen(
    onBack: () -> Unit,
    onAction: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0E17)),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "HİLE MENÜSÜ",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C3854)),
            ) { Text("Geri") }
        }
        CheatMenuContent(onAction = onAction, modifier = Modifier.weight(1f))
    }
}
