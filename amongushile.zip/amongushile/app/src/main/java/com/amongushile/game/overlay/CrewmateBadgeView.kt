package com.amongushile.game.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** Yüzer menü balonunda çizilen mini crewmate. */
class CrewmateBadgeView(context: Context) : View(context) {

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3FA7FF") }
    private val visorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CFE9FF") }
    private val legPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2B6FA8") }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 0, 0, 0) }
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#59D0FF")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = w * 0.16f

        canvas.drawCircle(w / 2f, h / 2f, w * 0.46f, shadowPaint)

        // gövde
        val body = RectF(pad, pad * 1.1f, w - pad, h - pad * 1.15f)
        canvas.drawRoundRect(body, w * 0.22f, w * 0.22f, bodyPaint)
        // sırt çantası
        canvas.drawRoundRect(
            RectF(pad * 0.45f, body.top + h * 0.12f, pad * 1.15f, body.bottom - h * 0.12f),
            w * 0.08f, w * 0.08f, legPaint
        )
        // vizör
        canvas.drawRoundRect(
            RectF(body.left + w * 0.18f, body.top + h * 0.12f, body.right - w * 0.08f, body.top + h * 0.42f),
            w * 0.1f, w * 0.1f, visorPaint
        )
        // bacaklar
        canvas.drawRoundRect(
            RectF(body.left + w * 0.12f, body.bottom - h * 0.02f, body.left + w * 0.44f, body.bottom + h * 0.06f),
            w * 0.05f, w * 0.05f, legPaint
        )
        canvas.drawRoundRect(
            RectF(body.right - w * 0.44f, body.bottom - h * 0.02f, body.right - w * 0.12f, body.bottom + h * 0.06f),
            w * 0.05f, w * 0.05f, legPaint
        )
        // hile rozeti
        outlinePaint.strokeWidth = w * 0.05f
        canvas.drawCircle(w / 2f, h / 2f, w * 0.44f, outlinePaint)
    }
}
