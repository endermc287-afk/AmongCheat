package com.amongushile.game.ui.game

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp

/** Sanal joystick: hareket yönünü ve büyüklüğünü bildirir. */
@Composable
fun Joystick(
    modifier: Modifier = Modifier,
    onMove: (Float, Float) -> Unit,
) {
    val radius = 58.dp
    val density = LocalDensity.current
    var center by remember { mutableStateOf(Offset.Zero) }
    var knob by remember { mutableStateOf(Offset.Zero) }
    var active by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .size(140.dp)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { pos ->
                        center = pos
                        knob = pos
                        active = true
                        onMove(0f, 0f)
                    },
                    onDragEnd = {
                        active = false
                        knob = center
                        onMove(0f, 0f)
                    },
                    onDrag = { change, _ ->
                        knob = change.position
                        val dx = knob.x - center.x
                        val dy = knob.y - center.y
                        val len = kotlin.math.sqrt(dx * dx + dy * dy)
                        val maxPx = with(density) { radius.toPx() }
                        val k = if (len > maxPx && len > 0f) maxPx / len else 1f
                        onMove(dx * k / maxPx, dy * k / maxPx)
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = with(density) { radius.toPx() }
            val c = if (active) center else Offset(size.width / 2f, size.height / 2f)
            val knobPos = if (active) knob else c
            drawCircle(
                color = Color(0xFF3FA7FF).copy(alpha = 0.14f),
                radius = r,
                center = c,
            )
            drawCircle(
                color = Color(0xFF59D0FF).copy(alpha = 0.55f),
                radius = r,
                center = c,
                style = Stroke(width = 3f),
            )
            drawCircle(
                color = Color(0xFF59D0FF).copy(alpha = 0.85f),
                radius = r * 0.34f,
                center = knobPos,
            )
        }
    }
}
