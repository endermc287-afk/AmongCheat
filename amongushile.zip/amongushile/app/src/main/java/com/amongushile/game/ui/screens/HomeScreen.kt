package com.amongushile.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amongushile.game.ui.theme.Gri
import com.amongushile.game.ui.theme.Kirmizi
import com.amongushile.game.ui.theme.Mavi
import com.amongushile.game.ui.theme.Panel
import com.amongushile.game.ui.theme.Sari
import com.amongushile.game.ui.theme.Yesil

/**
 * Ana ekran: Among Us durumu, açma butonu, yüzer menü ve modlar.
 */
@Composable
fun HomeScreen(
    amongUsPackage: String?,
    overlayAllowed: Boolean,
    overlayRunning: Boolean,
    accessibilityOn: Boolean,
    activeCheats: Int,
    onLaunchGame: () -> Unit,
    onOverlayToggle: (Boolean) -> Unit,
    onAccessibilityClick: () -> Unit,
    onOpenCheats: () -> Unit,
    onPractice: () -> Unit,
    onOnline: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0E17))
            .verticalScroll(rememberScrollState())
            .padding(18.dp),
    ) {
        // Başlık
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "AMONG US HİLESİ",
                color = Mavi,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = "Root gerektirmez • Yüzer menü • Kendi host'un",
                color = Gri,
                fontSize = 12.sp,
            )
        }
        Spacer(Modifier.height(16.dp))

        // Among Us durumu
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(16.dp))
                .border(1.dp, (if (amongUsPackage != null) Yesil else Kirmizi).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(14.dp),
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(if (amongUsPackage != null) Yesil else Kirmizi, RoundedCornerShape(6.dp))
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (amongUsPackage != null) "Among Us kurulu" else "Among Us bulunamadı",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f),
                    )
                }
                if (amongUsPackage != null) {
                    Text(amongUsPackage, color = Gri, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = onLaunchGame,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Mavi),
                ) { Text("AMONG US'U BUL VE AÇ") }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Yüzer menü
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(16.dp))
                .padding(14.dp),
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Yüzer Menü", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (!overlayAllowed) "Önce 'Yüzer menü' iznini ver" else "Oyunun üstünde hile menüsü",
                            color = if (!overlayAllowed) Sari else Gri,
                            fontSize = 11.sp,
                        )
                    }
                    Switch(
                        checked = overlayRunning,
                        onCheckedChange = { onOverlayToggle(it) },
                        enabled = overlayAllowed,
                    )
                }
                if (!overlayAllowed) {
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { onOverlayToggle(true) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Sari),
                    ) { Text("Yüzer Menü İznini Ver") }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Erişilebilirlik (gerçek oyunda otomasyon)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(16.dp))
                .clickable { onAccessibilityClick() }
                .padding(14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Oyun Otomasyonu", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = if (accessibilityOn) "Açık - gerçek Among Us üzerinde çalışıyor" else "Kapalı - Ayarlar > Erişilebilirlik",
                        color = if (accessibilityOn) Yesil else Gri,
                        fontSize = 11.sp,
                    )
                }
                Text(if (accessibilityOn) "AÇIK" else "KAPALI", color = if (accessibilityOn) Yesil else Gri, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(16.dp))

        Text("MODLAR", color = Mavi, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        ModeCard(
            title = "Hile Menüsü",
            desc = "Always Impostor, Impostor Finder, Speed Hack, Player ESP, Kill All, Kick All...",
            badge = if (activeCheats > 0) "$activeCheats aktif" else "",
            onClick = onOpenCheats,
        )
        Spacer(Modifier.height(8.dp))
        ModeCard(
            title = "Antrenman (Botlarla)",
            desc = "Cihazda çalışan offline oyun. Bütün hileler burada gerçekten çalışır.",
            onClick = onPractice,
        )
        Spacer(Modifier.height(8.dp))
        ModeCard(
            title = "Çevrimiçi - Kendi Host",
            desc = "Kendi sunucuna bağlan, lobide oyna. Hileler sunucu tarafında uygulanır.",
            onClick = onOnline,
        )

        Spacer(Modifier.height(18.dp))
        Text(
            text = "Gerçek Among Us'ta rol sunucu tarafından belirlendiği için " +
                "\"Her Zaman Hileci\" yalnızca kendi host'un ve antrenmanda etkilidir. " +
                "Root'suz overlay + otomasyon gerçek oyunda da kullanılabilir.",
            color = Gri,
            fontSize = 11.sp,
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ModeCard(
    title: String,
    desc: String,
    badge: String = "",
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(desc, color = Gri, fontSize = 11.sp)
            }
            if (badge.isNotBlank()) {
                Spacer(Modifier.width(8.dp))
                Text(
                    text = badge,
                    color = Mavi,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(Mavi.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }
        }
    }
}
