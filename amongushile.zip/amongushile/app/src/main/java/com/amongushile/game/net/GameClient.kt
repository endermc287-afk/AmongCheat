package com.amongushile.game.net

import com.amongushile.core.ChatMessage
import com.amongushile.core.GameSnapshot
import com.amongushile.core.Input
import com.amongushile.core.Protocol
import com.amongushile.core.Role
import com.amongushile.core.SabotageType
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Kendi sunucuna bağlanan istemci. Protokol core içindeki [Protocol] ile aynı.
 */
class GameClient(
    private val host: String,
    private val port: Int,
    private val playerName: String,
    private val colorIndex: Int,
) {
    private var socket: Socket? = null
    private var writer: PrintWriter? = null
    private var readerThread: Thread? = null

    @Volatile
    private var running = false

    val snapshot: MutableStateFlow<GameSnapshot> = MutableStateFlow(GameSnapshot())
    val lobby: MutableStateFlow<List<Protocol.LobbyPlayer>> = MutableStateFlow(emptyList())
    val roomCode: MutableStateFlow<String> = MutableStateFlow("")
    val myRole: MutableStateFlow<Role?> = MutableStateFlow(null)
    val status: MutableStateFlow<String> = MutableStateFlow("Bağlanıyor...")
    val error: MutableStateFlow<String?> = MutableStateFlow(null)
    val gameOver: MutableStateFlow<String?> = MutableStateFlow(null)
    val chat: MutableSharedFlow<ChatMessage> = MutableSharedFlow(extraBufferCapacity = 64)

    private var latestInput = Input.NONE

    // ------------------------------------------------------------ bağlantı

    fun connect(onReady: () -> Unit) {
        Thread {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(host, port), 6000)
                s.tcpNoDelay = true
                socket = s
                val w = PrintWriter(s.getOutputStream(), true, Charsets.UTF_8)
                writer = w
                running = true
                status.value = "Bağlandı: $host:$port"

                send(Protocol.encode(Protocol.HELLO, playerName, colorIndex))

                readerThread = Thread {
                    val r = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                    try {
                        while (running) {
                            val line = r.readLine() ?: break
                            handleLine(line)
                        }
                    } catch (e: Exception) {
                        if (running) error.value = "Bağlantı koptu: ${e.message}"
                    }
                }
                readerThread?.start()
                onReady()
            } catch (e: Exception) {
                error.value = "Bağlanılamadı ($host:$port): ${e.message}"
                status.value = "Bağlanılamadı"
            }
        }.apply { isDaemon = true }.start()
    }

    fun disconnect() {
        running = false
        try {
            socket?.close()
        } catch (ignored: Exception) {
        }
        socket = null
        writer = null
    }

    fun send(line: String) {
        val w = writer ?: return
        try {
            w.println(line)
            w.flush()
        } catch (e: Exception) {
            error.value = "Gönderilemedi: ${e.message}"
        }
    }

    // ------------------------------------------------------------ komutlar

    fun createRoom() = send(Protocol.encode(Protocol.CREATE, ""))
    fun joinRoom(code: String) = send(Protocol.encode(Protocol.JOIN, code.uppercase()))
    fun startGame() = send(Protocol.START)
    fun addBots(count: Int) = send(Protocol.encode(Protocol.BOT, count))
    fun setCheat(key: String, value: String) = send(Protocol.encode(Protocol.SETCH, key, value))

    /** Tüm hile ayarlarını sunucuya gönderir (girilen her odada geçerli olur). */
    fun pushCheats(cheats: com.amongushile.core.CheatSettings) {
        fun b(v: Boolean) = if (v) "1" else "0"
        setCheat("alwaysImpostor", b(cheats.alwaysImpostor))
        setCheat("revealRoles", b(cheats.revealRoles))
        setCheat("playerEsp", b(cheats.playerEsp))
        setCheat("instantTasks", b(cheats.instantTasks))
        setCheat("skipKillCooldown", b(cheats.skipKillCooldown))
        setCheat("noMeetings", b(cheats.noMeetings))
        setCheat("ghostMode", b(cheats.ghostMode))
        setCheat("freeCamera", b(cheats.freeCamera))
        setCheat("unlockSkins", b(cheats.unlockSkins))
        setCheat("noVoteCooldown", b(cheats.noVoteCooldown))
        setCheat("speed", cheats.walkSpeedMultiplier.toString())
        setCheat("impostorCount", cheats.impostorCount.toString())
    }
    fun applyCheatAction(key: String) = send(Protocol.encode(key.uppercase()))

    fun move(dx: Float, dy: Float) {
        latestInput = latestInput.copy(moveX = dx, moveY = dy)
        send(Protocol.encode(Protocol.INPUT, dx.toFloat(), dy.toFloat()))
    }

    fun use() = send(Protocol.USE)
    fun kill(targetId: Int) = send(Protocol.encode(Protocol.KILL, targetId))
    fun completeTask(stationId: Int) = send(Protocol.encode(Protocol.TASK, stationId))
    fun report() = send(Protocol.REPORT)
    fun emergency() = send(Protocol.EMERGENCY)
    fun vote(targetId: Int) = send(Protocol.encode(Protocol.VOTE, targetId))
    fun say(text: String) = send(Protocol.encode(Protocol.CHAT, Protocol.escape(text)))
    fun sabotage(type: SabotageType) = send(Protocol.encode(Protocol.SAB, type.name))
    fun vent(ventId: Int) = send(Protocol.encode(Protocol.VENT, ventId))

    // ------------------------------------------------------------ gelen mesajlar

    private fun handleLine(line: String) {
        val f = Protocol.split(line)
        when (f.getOrNull(0) ?: return) {
            Protocol.OK -> status.value = f.drop(1).joinToString(" ").ifBlank { "Bağlandı" }
            Protocol.ERR -> error.value = f.drop(1).joinToString(" ")
            Protocol.MSG -> status.value = f.drop(1).joinToString(" ")
            Protocol.LOBBY -> {
                val decoded = Protocol.decodeLobby(f.drop(1).joinToString("|"))
                if (decoded != null) {
                    roomCode.value = decoded.first
                    lobby.value = decoded.second
                    // Odaya girildi: hile ayarlarını sunucuya gönder (bu odada da geçerli)
                    pushCheats(com.amongushile.game.data.HileDurumu.cheats)
                }
            }
            Protocol.ROLE -> {
                myRole.value = Role.fromName(f.getOrNull(1) ?: "CREWMATE")
            }
            Protocol.SNAP -> {
                val decoded = Protocol.decodeSnapshot(f.drop(1).joinToString("|"))
                if (decoded != null) {
                    snapshot.value = GameSnapshot(
                        phase = decoded.phase,
                        localPlayerId = decoded.localPlayerId,
                        players = decoded.players,
                        tasks = com.amongushile.core.ShipMap.STANDARD.taskStations,
                        completedTasks = decoded.completedTasks,
                        myTasks = decoded.myTasks,
                        totalTaskSlots = decoded.totalTaskSlots,
                        globalTasksDone = decoded.globalTasksDone,
                        sabotage = decoded.sabotage,
                        bodies = decoded.bodies,
                        meeting = decoded.meeting,
                        winner = decoded.winner,
                        cheats = com.amongushile.game.data.HileDurumu.cheats,
                        emergencyUsable = decoded.emergencyUsable,
                        killCooldown = decoded.killCooldown,
                        ventAvailable = decoded.ventAvailable,
                    )
                }
            }
            Protocol.CHAT -> {
                val pid = f.getOrNull(1)?.toIntOrNull() ?: -1
                val name = f.getOrNull(2) ?: "Oyuncu"
                val text = f.drop(3).joinToString("|")
                chat.tryEmit(ChatMessage(System.currentTimeMillis().toInt(), pid, name, text))
            }
            Protocol.OVER -> {
                gameOver.value = f.getOrNull(1) ?: "OVER"
                status.value = "Oyun bitti"
            }
            Protocol.PONG -> Unit
        }
    }
}

/** Aktif çevrimiçi oturum (yüzer menü hile komutlarını buraya iletir). */
object OnlineSession {
    @Volatile
    var current: GameClient? = null
}
