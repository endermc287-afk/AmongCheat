package com.amongushile.game.ui.game

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amongushile.core.TaskKind
import com.amongushile.core.TaskStation
import com.amongushile.game.ui.theme.Mavi
import com.amongushile.game.ui.theme.Panel
import com.amongushile.game.ui.theme.Sari
import kotlinx.coroutines.delay

/** Görev minigamesi ekranı. */
@Composable
fun TaskMinigame(
    station: TaskStation,
    instant: Boolean,
    onComplete: () -> Unit,
    onClose: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEE070A12))
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = station.title,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = station.room,
            color = Color(0xFF8FA3BF),
            fontSize = 13.sp,
            modifier = Modifier.padding(bottom = 18.dp),
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(18.dp))
                .border(2.dp, Mavi.copy(alpha = 0.5f), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center,
        ) {
            when (station.kind) {
                TaskKind.WIRES -> WiresPuzzle(onComplete)
                TaskKind.CARD -> CardSwipePuzzle(onComplete)
                TaskKind.KEYPAD -> KeypadPuzzle(station.id, onComplete)
                TaskKind.CALIBRATE -> CalibratePuzzle(onComplete)
                TaskKind.TRASH -> HoldPuzzle("Çöbü kaldır", onComplete)
                TaskKind.SCAN -> HoldPuzzle("Taramayı sürdür", onComplete)
            }
        }

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onComplete,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3FE07A)),
            ) { Text(if (instant) "ANINDA BITIR" else "ONAYLA") }
            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C3854)),
            ) { Text("VAZGEÇ") }
        }
    }
}

// ------------------------------------------------------------------ kablo

private val KabloRenkleri = listOf(
    Color(0xFFFF5B5B), Color(0xFF3FA7FF), Color(0xFFFFC94D),
    Color(0xFF3FE07A), Color(0xFFB87CFF),
)

@Composable
private fun WiresPuzzle(onComplete: () -> Unit) {
    val left = remember { KabloRenkleri.shuffled() }
    val right = remember { KabloRenkleri.shuffled() }
    var selectedLeft by remember { mutableIntStateOf(-1) }
    val connections = remember { mutableMapOf<Int, Int>() }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            left.forEachIndexed { index, color ->
                Circle(color = color, active = selectedLeft == index, onClick = {
                    selectedLeft = index
                })
            }
        }

        Text(
            text = if (selectedLeft >= 0) "Şimdi sağdaki eşleşen rengi seç" else "Soldan bir kablo seç",
            color = Color(0xFF8FA3BF),
            fontSize = 13.sp,
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            right.forEachIndexed { index, color ->
                Circle(color = color, active = connections.values.contains(index), onClick = {
                    if (selectedLeft >= 0 && left[selectedLeft] == color) {
                        connections[selectedLeft] = index
                        selectedLeft = -1
                        if (connections.size == KabloRenkleri.size) onComplete()
                    }
                })
            }
        }
    }
}

@Composable
private fun Circle(color: Color, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(42.dp)
            .background(color.copy(alpha = if (active) 1f else 0.75f), RoundedCornerShape(21.dp))
            .border(if (active) 3.dp else 1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(21.dp))
            .clickable { onClick() }
    )
}

// ------------------------------------------------------------------ kart

@Composable
private fun CardSwipePuzzle(onComplete: () -> Unit) {
    var offset by remember { mutableFloatStateOf(0f) }
    var done by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "Kartı yukarı kaydır",
                color = Color(0xFF8FA3BF),
                fontSize = 14.sp,
                modifier = Modifier.padding(bottom = 20.dp),
            )
            Box(
                modifier = Modifier
                    .width(160.dp)
                    .height(220.dp)
                    .background(Color(0xFF2C3854), RoundedCornerShape(12.dp))
                    .border(2.dp, Sari.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onVerticalDrag = { change, dragAmount ->
                                change.consume()
                                offset += dragAmount
                            },
                            onDragEnd = {
                                val fast = offset < -260f
                                if (fast) {
                                    done = true
                                    onComplete()
                                } else {
                                    failed = true
                                    offset = 0f
                                }
                            },
                        )
                    },
                contentAlignment = Alignment.Center,
            ) {
                Text("KART", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            if (failed) {
                Text("Çok yavaş! Tekrar dene.", color = Color(0xFFFF5B5B), fontSize = 13.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ şifre

@Composable
private fun KeypadPuzzle(stationId: Int, onComplete: () -> Unit) {
    val code = remember(stationId) {
        val rnd = kotlin.random.Random(stationId * 977L)
        (1..4).map { rnd.nextInt(1, 10) }
    }
    var entered by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Şifre: ${code.joinToString(" ")}", color = Sari, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(
            text = "Girdiğin: ${entered.ifEmpty { "-" }}",
            color = Color(0xFF8FA3BF),
            fontSize = 16.sp,
            modifier = Modifier.padding(vertical = 16.dp),
        )
        for (row in 0..2) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                for (col in 0..2) {
                    val digit = row * 3 + col + 1
                    KeypadButton(digit.toString()) {
                        if (entered.length < 4) {
                            entered += digit
                            if (entered.length == 4) {
                                if (entered == code.joinToString("")) onComplete() else {
                                    error = true
                                    entered = ""
                                }
                            }
                        }
                    }
                }
            }
        }
        if (error) Text("Yanlış şifre!", color = Color(0xFFFF5B5B), fontSize = 13.sp)
    }
}

@Composable
private fun KeypadButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(64.dp)
            .background(Color(0xFF2C3854), RoundedCornerShape(12.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

// ------------------------------------------------------------------ kalibrasyon

@Composable
private fun CalibratePuzzle(onComplete: () -> Unit) {
    var marker by remember { mutableFloatStateOf(0f) }
    var success by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        var v = 0f
        while (!success) {
            delay(28)
            v += 0.028f
            if (v > 1f) v = 0f
            marker = v
        }
    }

    Box(
        modifier = Modifier.fillMaxSize().padding(30.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("İşaretçi yeşil alandayken dokun", color = Color(0xFF8FA3BF), fontSize = 13.sp)
            Spacer(Modifier.height(20.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
                    .background(Color(0xFF141A2B), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.CenterStart,
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.3f)
                        .height(70.dp)
                        .background(Color(0xFF3FE07A).copy(alpha = 0.35f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("HEDEF", color = Color(0xFF3FE07A), fontSize = 11.sp)
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { _: Offset -> },
                                onDrag = { change: androidx.compose.ui.input.pointer.PointerInputChange, _: Offset ->
                                    change.consume()
                                    marker = (change.position.x / size.width).coerceIn(0f, 1f)
                                },
                            )
                        },
                    contentAlignment = Alignment.CenterStart,
                ) {}
                Box(
                    modifier = Modifier
                        .padding(start = 0.dp)
                        .fillMaxWidth()
                        .height(70.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        val x = marker * size.width
                        drawCircle(color = Color(0xFFFFC94D), radius = 18f, center = Offset(x, size.height / 2f))
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    if (marker in 0.30f..0.60f) {
                        success = true
                        onComplete()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Mavi),
            ) { Text("KALİBRE ET") }
        }
    }
}

// ------------------------------------------------------------------ basılı tut

@Composable
private fun HoldPuzzle(label: String, onComplete: () -> Unit) {
    var progress by remember { mutableFloatStateOf(0f) }
    var holding by remember { mutableStateOf(false) }

    LaunchedEffect(holding) {
        while (holding && progress < 1f) {
            delay(40)
            progress = (progress + 0.02f).coerceAtMost(1f)
        }
        if (progress >= 1f) onComplete()
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(30.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(label, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .background(Color(0xFF141A2B), RoundedCornerShape(14.dp))
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { _: Offset -> holding = true },
                        onDrag = { _: androidx.compose.ui.input.pointer.PointerInputChange, _: Offset -> },
                        onDragEnd = { holding = false },
                        onDragCancel = { holding = false },
                    )
                },
            contentAlignment = Alignment.CenterStart,
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress.coerceIn(0.02f, 1f))
                    .height(64.dp)
                    .background(Mavi, RoundedCornerShape(14.dp))
            )
            Text(
                text = if (holding) "Basılı tut..." else "Basılı tut",
                color = Color.White,
                fontSize = 15.sp,
                modifier = Modifier.padding(start = 16.dp),
            )
        }
    }
}
