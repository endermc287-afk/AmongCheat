package com.amongushile.game.launch

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast

enum class LaunchResult { LAUNCHED, NOT_INSTALLED, FAILED }

/** Among Us'u (ve olası klonlarını) bulup açan yardımcı. Root gerektirmez. */
object AmongUsLauncher {

    val candidates = listOf(
        "com.innersloth.spacemafia",
        "com.innersloth.spacemafia.free",
        "com.amongus.mobile",
        "com.amongusclone.game",
        "com.amongus.hile",
    )

    /** Cihazda kurulu olan Among Us paket adı (yoksa null). */
    fun installedPackage(context: Context): String? {
        val pm = context.packageManager
        for (pkg in candidates) {
            try {
                pm.getPackageInfo(pkg, 0)
                return pkg
            } catch (e: PackageManager.NameNotFoundException) {
                // devam
            }
        }
        return null
    }

    /** Among Us'u bulur ve açar. Bulunamazsa Play Store'a yönlendirir. */
    fun launch(context: Context): LaunchResult {
        val pkg = installedPackage(context)
        if (pkg == null) {
            openStore(context)
            return LaunchResult.NOT_INSTALLED
        }
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            openStore(context)
            return LaunchResult.FAILED
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            LaunchResult.LAUNCHED
        } catch (e: Exception) {
            LaunchResult.FAILED
        }
    }

    fun openStore(context: Context) {
        val store = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.innersloth.spacemafia"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.innersloth.spacemafia"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(store)
        } catch (e: Exception) {
            try {
                context.startActivity(web)
            } catch (e2: Exception) {
                Toast.makeText(context, "Play Store açılamadı", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expected = "${context.packageName}/${AmongUsAutoServiceName::class.java.name}"
        val enabled = try {
            android.provider.Settings.Secure.getString(
                context.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
            )
        } catch (e: Exception) {
            null
        } ?: return false
        return enabled.split(":").any { it.equals(expected, ignoreCase = true) }
    }
}

/** Erişilebilirlik servisinin tam sınıf adı (bilinçli olarak basit tutuldu). */
object AmongUsAutoServiceName {
    const val VALUE = "com.amongushile.game.accessibility.AmongUsAutoService"
}
