package com.amongushile.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import android.content.Intent
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amongushile.core.Phase
import com.amongushile.game.data.HileDurumu
import com.amongushile.game.game.RemoteGameSource
import com.amongushile.game.net.GameClient
import com.amongushile.game.net.OnlineSession
import com.amongushile.server.HileServer
import com.amongushile.game.ui.theme.Gri
import com.amongushile.game.ui.theme.Kirmizi
import com.amongushile.game.ui.theme.Mavi
import com.amongushile.game.ui.theme.Panel
import com.amongushile.game.ui.theme.Yesil

/** Çevrimiçi lobi ekranı: kendi sunucuna bağlan, oda kur, oyna. */
@Composable
fun OnlineScreen(onExit: () -> Unit) {
    var host by remember { mutableStateOf(HileDurumu.serverHost) }
    var port by remember { mutableStateOf(HileDurumu.serverPort.toString()) }
    var roomCode by remember { mutableStateOf("") }
    var client by remember { mutableStateOf<GameClient?>(null) }
    var started by remember { mutableStateOf(false) }
    var localServer by remember { mutableStateOf<HileServer?>(null) }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { localServer?.stop() }
    }

    val lobby by (client?.lobby ?: kotlinx.coroutines.flow.MutableStateFlow(emptyList())).collectAsState()
    val status by (client?.status ?: kotlinx.coroutines.flow.MutableStateFlow("")).collectAsState()
    val error by (client?.error ?: kotlinx.coroutines.flow.MutableStateFlow<String?>(null)).collectAsState()
    val snapshot by (client?.snapshot ?: kotlinx.coroutines.flow.MutableStateFlow(com.amongushile.core.GameSnapshot())).collectAsState()
    val code by (client?.roomCode ?: kotlinx.coroutines.flow.MutableStateFlow("")).collectAsState()

    LaunchedEffect(snapshot.phase) {
        if (snapshot.phase != Phase.LOBBY && client != null) started = true
    }

    if (started && client != null) {
        val source = remember(client) { RemoteGameSource(client!!) }
        GameScreen(source = source, onExit = {
            source.dispose()
            OnlineSession.current = null
            client = null
            started = false
            onExit()
        })
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0E17))
            .verticalScroll(rememberScrollState())
            .padding(18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "ÇEVRİMİÇİ - KENDİ HOST",
                color = Mavi,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            Button(
                onClick = {
                    client?.disconnect()
                    OnlineSession.current = null
                    client = null
                    onExit()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C3854)),
            ) { Text("Geri") }
        }

        Spacer(Modifier.height(14.dp))

        Text(
            text = "Sunucu adresi (kendi makinen/VPS):",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = host,
            onValueChange = { host = it; HileDurumu.serverHost = it },
            placeholder = { Text("192.168.1.10 veya sunucu.com", color = Gri) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
        )
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = port,
            onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) },
            label = { Text("Port") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
        )

        Spacer(Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(14.dp))
                .padding(12.dp),
        ) {
            Column {
                Text("KENDİ HOST'UN", color = Mavi, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = if (localServer != null)
                        "Sunucu çalışıyor: ${HileServer.localIp()}:${localServer!!.actualPort}"
                    else
                        "Bu telefonu kendi sunucun yap: arkadaşların Wi-Fi üzerinden sana bağlanır.",
                    color = Gri,
                    fontSize = 11.sp,
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        val running = localServer
                        if (running != null) {
                            running.stop()
                            localServer = null
                            client?.disconnect()
                            OnlineSession.current = null
                            client = null
                        } else {
                            val s = HileServer(port = 8080, botCount = 3, serverName = "Benim Host'um")
                            if (s.start()) {
                                localServer = s
                                host = HileServer.localIp()
                                port = s.actualPort.toString()
                                // Kendi sunucumuza otomatik baglan ve odayi kur
                                val c = GameClient(
                                    "127.0.0.1", s.actualPort,
                                    HileDurumu.playerName.ifBlank { "Host" }, 0,
                                )
                                client = c
                                OnlineSession.current = c
                                c.connect {
                                    c.createRoom()
                                    c.addBots(2)
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (localServer != null) Color(0xFF2C3854) else Yesil
                    ),
                ) {
                    Text(if (localServer != null) "HOST DURDUR" else "BU CİHAZDA HOST BAŞLAT")
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                val p = port.toIntOrNull() ?: 8080
                HileDurumu.serverHost = host
                HileDurumu.serverPort = p
                val c = GameClient(host, p, HileDurumu.playerName.ifBlank { "Oyuncu" }, (0..11).random())
                client = c
                OnlineSession.current = c
                c.connect { }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Mavi),
        ) { Text("BAĞLAN") }

        if (status.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(status, color = Gri, fontSize = 12.sp)
        }
        error?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = Kirmizi, fontSize = 12.sp)
        }

        if (client != null) {
            Spacer(Modifier.height(16.dp))
            Text("LOBİ", color = Mavi, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { client?.createRoom() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C3854)),
                ) { Text("Oda Kur") }
                Button(
                    onClick = { client?.addBots(3) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C3854)),
                ) { Text("Bot Ekle") }
                Button(
                    onClick = { client?.startGame() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Yesil),
                ) { Text("Başlat") }
            }

            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = roomCode,
                    onValueChange = { roomCode = it.uppercase().take(6) },
                    label = { Text("Oda kodu") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { client?.joinRoom(roomCode) },
                    colors = ButtonDefaults.buttonColors(containerColor = Mavi),
                ) { Text("Katıl") }
            }

            if (code.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Oda kodu: $code", color = Yesil, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "Arkadaşların ${host}:${port} adresine bağlanıp bu kodla odaya girsin.",
                            color = Gri,
                            fontSize = 11.sp,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val share = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "Among Us Hilesi odasına katıl!\nAdres: $host:$port\nOda kodu: $code",
                                )
                            }
                            context.startActivity(Intent.createChooser(share, "Odayı paylaş"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Mavi),
                    ) { Text("Paylaş") }
                }
            }

            Spacer(Modifier.height(10.dp))
            lobby.forEach { p ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Panel, RoundedCornerShape(10.dp))
                        .padding(10.dp),
                ) {
                    Text(
                        text = "${p.name}${if (p.isBot) " (bot)" else ""}",
                        color = Color.White,
                        fontSize = 13.sp,
                    )
                }
                Spacer(Modifier.height(6.dp))
            }

            Spacer(Modifier.height(10.dp))
            Text(
                text = "İpucu: Sunucuyu kendi bilgisayarında çalıştırmak için proje içindeki " +
                    "server klasöründeki komutu kullan. Telefon ve bilgisayar aynı Wi-Fi'da olmalı.",
                color = Gri,
                fontSize = 11.sp,
            )
        }
    }
}
