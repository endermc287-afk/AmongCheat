package com.amongushile.game.game

import com.amongushile.core.ChatMessage
import com.amongushile.core.GameConfig
import com.amongushile.core.GameEngine
import com.amongushile.core.GameSnapshot
import com.amongushile.core.Input
import com.amongushile.core.Player
import com.amongushile.core.Role
import com.amongushile.core.SabotageType
import com.amongushile.core.TaskStation
import com.amongushile.core.UseResult
import com.amongushile.game.data.HileDurumu
import com.amongushile.game.net.GameClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Oyun ekranının ihtiyaç duyduğu ortak arayüz (yerel motor veya online sunucu). */
interface GameSource {
    val snapshot: StateFlow<GameSnapshot>
    val chat: SharedFlow<ChatMessage>
    val status: StateFlow<String>
    val gameOver: StateFlow<String?>
    val events: SharedFlow<GameEvent>

    fun move(dx: Float, dy: Float)
    fun use()
    fun kill()
    fun completeTask(stationId: Int)
    fun report()
    fun emergency()
    fun vote(targetId: Int)
    fun say(text: String)
    fun sabotage(type: SabotageType)
    fun vent(ventId: Int)
    fun cheatAction(key: String)
    fun dispose()
}

sealed class GameEvent {
    data class OpenTask(val station: TaskStation) : GameEvent()
    data class Notice(val text: String) : GameEvent()
    object Vent : GameEvent()
}

/** Cihaz üzerinde çalışan antrenman (botlarla). Hileler burada da gerçekten etkilidir. */
class LocalGameSource(
    name: String,
    colorIndex: Int,
    botCount: Int = 7,
) : GameSource {

    private val engine = GameEngine(GameConfig(playerCount = 8, taskCount = 5))
    private var localPlayer: Player? = null
    private var job: Job? = null

    override val snapshot: MutableStateFlow<GameSnapshot> = MutableStateFlow(GameSnapshot())
    override val chat: MutableSharedFlow<ChatMessage> = MutableSharedFlow(extraBufferCapacity = 64)
    override val status: MutableStateFlow<String> = MutableStateFlow("Antrenman hazırlanıyor")
    override val gameOver: MutableStateFlow<String?> = MutableStateFlow(null)
    override val events: MutableSharedFlow<GameEvent> = MutableSharedFlow(extraBufferCapacity = 16)

    private var input = Input.NONE

    init {
        val me = engine.addPlayer(name, colorIndex, isBot = false)
        localPlayer = me
        engine.localPlayerId = me.id
        repeat(botCount) { engine.addPlayer("Bot ${it + 1}", it + 1, isBot = true) }
        engine.cheats = HileDurumu.cheats
        engine.start()
        status.value = "Antrenman başladı! ${engine.players.size} oyuncu."
    }

    fun start(scope: CoroutineScope) {
        job = scope.launch {
            var last = System.nanoTime()
            while (isActive) {
                delay(16)
                val now = System.nanoTime()
                val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.1f)
                last = now
                engine.cheats = HileDurumu.cheats
                // "Her Zaman Hileci" açılırsa rol anında değişsin (offline da)
                val cheats = HileDurumu.cheats
                val me = localPlayer
                if (me != null) {
                    if (cheats.alwaysImpostor && me.role != Role.IMPOSTOR) engine.forceImpostor(me.id)
                    if (!cheats.alwaysImpostor && me.role == Role.IMPOSTOR && !engine.alwaysImpostorIds.contains(me.id)) {
                        engine.forceCrewmate(me.id)
                    }
                }
                if (me != null) {
                    engine.update(dt, mapOf(me.id to input))
                } else {
                    engine.update(dt)
                }
                input = input.copy(use = false, kill = false, taskDone = false, report = false, emergency = false)
                snapshot.value = engine.snapshot()
                engine.winner?.let { w ->
                    if (gameOver.value == null) {
                        val text = if (w == com.amongushile.core.Winner.CREWMATES) "Mürettebat kazandı!" else "Hileciler kazandı!"
                        gameOver.value = text
                        status.value = text
                    }
                }
            }
        }
    }

    override fun move(dx: Float, dy: Float) {
        input = input.copy(moveX = dx, moveY = dy)
    }

    override fun use() {
        val me = localPlayer ?: return
        when (val r = engine.handleUse(me.id)) {
            is UseResult.Task -> events.tryEmit(GameEvent.OpenTask(r.station))
            is UseResult.Vent -> events.tryEmit(GameEvent.Vent)
            is UseResult.ReportBody -> events.tryEmit(GameEvent.Notice("Ceset bildirildi"))
            is UseResult.Message -> events.tryEmit(GameEvent.Notice(r.text))
            UseResult.None -> Unit
            else -> Unit
        }
    }

    override fun kill() {
        val me = localPlayer ?: return
        val target = engine.nearestTargetFor(me)
        if (target == -1) {
            events.tryEmit(GameEvent.Notice("Yakında hedef yok"))
        } else if (!engine.tryKill(me.id, target)) {
            events.tryEmit(GameEvent.Notice("Öldürme için bekleme süresi var"))
        }
    }

    override fun completeTask(stationId: Int) {
        val me = localPlayer ?: return
        if (!engine.completeTask(me.id, stationId)) {
            events.tryEmit(GameEvent.Notice("Görev tamamlanamadı"))
        }
    }

    override fun report() {
        val me = localPlayer ?: return
        if (engine.tryReportNearBody(me.id) == -1) {
            events.tryEmit(GameEvent.Notice("Yakında ceset yok"))
        }
    }

    override fun emergency() {
        val me = localPlayer ?: return
        if (!engine.callEmergency(me.id)) {
            events.tryEmit(GameEvent.Notice("Toplantı çağrılamadı"))
        }
    }

    override fun vote(targetId: Int) {
        val me = localPlayer ?: return
        engine.castVote(me.id, targetId)
    }

    override fun say(text: String) {
        val me = localPlayer ?: return
        engine.sendChat(me.id, text)
    }

    override fun sabotage(type: SabotageType) {
        val me = localPlayer ?: return
        if (!engine.triggerSabotage(me.id, type)) {
            events.tryEmit(GameEvent.Notice("Sabotaj yapılamadı"))
        }
    }

    override fun vent(ventId: Int) {
        val me = localPlayer ?: return
        if (!engine.useVent(me.id, ventId)) {
            events.tryEmit(GameEvent.Notice("Havalandırma kullanılamadı"))
        }
    }

    override fun cheatAction(key: String) {
        when (key) {
            "killAll" -> {
                engine.killAllCheat()
                events.tryEmit(GameEvent.Notice("KILL ALL: mürettebatlar öldürüldü"))
            }
            "kickAll" -> events.tryEmit(GameEvent.Notice("KICK ALL yalnızca çevrimiçi lobide çalışır"))
            else -> events.tryEmit(GameEvent.Notice("Hile uygulandı: $key"))
        }
    }

    override fun dispose() {
        job?.cancel()
    }
}

/** Online (kendi sunucu) kaynağı. */
class RemoteGameSource(private val client: GameClient) : GameSource {
    override val snapshot: StateFlow<GameSnapshot> = client.snapshot
    override val chat: SharedFlow<ChatMessage> = client.chat
    override val status: StateFlow<String> = client.status
    override val gameOver: StateFlow<String?> = client.gameOver
    override val events: SharedFlow<GameEvent> = MutableSharedFlow(extraBufferCapacity = 16)

    override fun move(dx: Float, dy: Float) = client.move(dx, dy)
    override fun use() = client.use()
    override fun kill() = client.kill(-1)
    override fun completeTask(stationId: Int) = client.completeTask(stationId)
    override fun report() = client.report()
    override fun emergency() = client.emergency()
    override fun vote(targetId: Int) = client.vote(targetId)
    override fun say(text: String) = client.say(text)
    override fun sabotage(type: SabotageType) = client.sabotage(type)
    override fun vent(ventId: Int) = client.vent(ventId)
    override fun cheatAction(key: String) = client.applyCheatAction(key)
    override fun dispose() = client.disconnect()
}
