package com.amongushile.game.ui.game

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amongushile.core.ChatMessage
import com.amongushile.core.GameSnapshot
import com.amongushile.core.MeetingStage
import com.amongushile.core.Role
import com.amongushile.game.ui.theme.Gri
import com.amongushile.game.ui.theme.Kirmizi
import com.amongushile.game.ui.theme.Mavi
import com.amongushile.game.ui.theme.Panel
import com.amongushile.game.ui.theme.Sari
import com.amongushile.game.ui.theme.Yesil

/** Toplantı ekranı: sohbet, oylama ve atma sonucu. */
@Composable
fun MeetingView(
    snapshot: GameSnapshot,
    chat: List<ChatMessage>,
    onVote: (Int) -> Unit,
    onSay: (String) -> Unit,
    onLeave: () -> Unit,
) {
    val meeting = snapshot.meeting ?: return
    var text by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF2050812))
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column {
                Text(
                    text = when (meeting.reason) {
                        com.amongushile.core.MeetingReason.BODY -> "CESET BULUNDU"
                        com.amongushile.core.MeetingReason.BUTTON -> "ACİL TOPLANTI"
                        com.amongushile.core.MeetingReason.SABOTAGE -> "SABOTAJ TOPLANTISI"
                    },
                    color = Kirmizi,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = when (meeting.stage) {
                        MeetingStage.DISCUSSION -> "Tartışma: ${meeting.discussionLeft.toInt()} sn"
                        MeetingStage.VOTING -> "Oylama: ${meeting.votingLeft.toInt()} sn"
                        MeetingStage.RESULT -> "Sonuç"
                    },
                    color = Gri,
                    fontSize = 13.sp,
                )
            }
            Button(
                onClick = onLeave,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C3854)),
            ) { Text("Kapat") }
        }

        Spacer(Modifier.height(10.dp))

        // Oyuncular / oy sayıları
        val voteTally = remember(meeting.votes) {
            meeting.votes.values.filter { it != -1 }.groupingBy { it }.eachCount()
        }
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(snapshot.players.filter { it.alive }) { player ->
                val votes = voteTally[player.id] ?: 0
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Panel, RoundedCornerShape(10.dp))
                        .clickable(enabled = meeting.stage == MeetingStage.VOTING) {
                            onVote(player.id)
                        }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .background(Color(com.amongushile.core.Colors.color(player.colorIndex)), RoundedCornerShape(6.dp))
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(player.name, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    if (player.role != null && snapshot.cheats.revealRoles) {
                        Text(
                            text = if (player.role == Role.IMPOSTOR) "HİLECİ" else "MÜRETTEBAT",
                            color = if (player.role == Role.IMPOSTOR) Kirmizi else Yesil,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    Text("$votes oy", color = Mavi, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Sohbet
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(12.dp))
                .padding(10.dp),
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                items(chat.takeLast(60)) { msg ->
                    Text(
                        text = if (msg.system) msg.text else "${msg.name}: ${msg.text}",
                        color = if (msg.system) Sari else Color.White,
                        fontSize = 12.sp,
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        if (meeting.stage == MeetingStage.VOTING) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = { onVote(-1) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C3854)),
                    modifier = Modifier.weight(1f),
                ) { Text("ATLA") }
            }
            Spacer(Modifier.height(8.dp))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Mesaj yaz...", color = Gri) },
                modifier = Modifier.weight(1f),
                singleLine = true,
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = {
                    if (text.isNotBlank()) {
                        onSay(text)
                        text = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Mavi),
            ) { Text("Gönder") }
        }
    }
}
