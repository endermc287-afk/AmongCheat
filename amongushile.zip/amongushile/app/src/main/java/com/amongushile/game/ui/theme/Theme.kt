package com.amongushile.game.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Uzay = Color(0xFF0B0E17)
val Panel = Color(0xFF161C2C)
val PanelAcık = Color(0xFF1F2740)
val Mavi = Color(0xFF3FA7FF)
val MaviKoyu = Color(0xFF1D6FB8)
val Kirmizi = Color(0xFFFF5B5B)
val Yesil = Color(0xFF3FE07A)
val Sari = Color(0xFFFFC94D)
val Gri = Color(0xFF8FA3BF)
val Beyaz = Color(0xFFF2F6FF)

private val KoyuRenkler = darkColorScheme(
    primary = Mavi,
    onPrimary = Color.White,
    secondary = Kirmizi,
    background = Uzay,
    onBackground = Beyaz,
    surface = Panel,
    onSurface = Beyaz,
    surfaceVariant = PanelAcık,
    onSurfaceVariant = Gri,
    outline = Color(0xFF2C3854),
)

private val Tipografi = Typography(
    titleLarge = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Beyaz),
    titleMedium = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Beyaz),
    bodyLarge = TextStyle(fontSize = 15.sp, color = Beyaz),
    bodyMedium = TextStyle(fontSize = 13.sp, color = Gri),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
)

@Composable
fun AmongUsHileTheme(content: @Composable () -> Unit) {
    @Suppress("UNUSED_EXPRESSION")
    isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = KoyuRenkler,
        typography = Tipografi,
        content = content,
    )
}
