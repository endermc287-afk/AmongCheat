package com.amongushile.game.data

import android.content.Context
import android.content.SharedPreferences
import com.amongushile.core.CheatSettings
import com.amongushile.core.GameEngine

/**
 * Uygulama geneli durum: hile ayarları, sunucu adresi, overlay tercihleri.
 * Hem ana ekran hem yüzer menü aynı örneği kullanır.
 */
object HileDurumu {

    private const val PREFS = "among_us_hile_prefs"
    private lateinit var prefs: SharedPreferences

    private val listeners = mutableListOf<(String, String) -> Unit>()

    fun init(context: Context) {
        if (!::prefs.isInitialized) {
            prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        }
    }

    fun addListener(l: (String, String) -> Unit) {
        synchronized(listeners) { listeners.add(l) }
    }

    fun removeListener(l: (String, String) -> Unit) {
        synchronized(listeners) { listeners.remove(l) }
    }

    private fun notify(key: String, value: String) {
        val copy = synchronized(listeners) { listeners.toList() }
        copy.forEach { it(key, value) }
    }

    // ---------------------------------------------------------------- hile ayarları

    private val cheatKeys = listOf(
        "alwaysImpostor", "noMeetings", "instantTasks", "skipKillCooldown",
        "freeCamera", "unlockSkins", "ghostMode", "revealRoles",
        "noVoteCooldown", "playerEsp",
    )

    var cheats: CheatSettings
        get() {
            val flags = mutableListOf<String>()
            cheatKeys.forEach { k -> if (prefs.getBoolean(k, false)) flags += k }
            val speed = prefs.getFloat("speed", 1f)
            if (speed > 1.01f) flags += "speed"
            val impostors = prefs.getInt("impostorCount", 1)
            repeat((impostors - 1).coerceAtLeast(0)) { flags += "impostor" }
            return GameEngine.cheatsFromFlags(flags.joinToString(","))
                .copy(walkSpeedMultiplier = speed, impostorCount = impostors)
        }
        set(value) {
            val e = prefs.edit()
            cheatKeys.forEach { k -> e.putBoolean(k, false) }
            e.remove("speed")
            e.remove("impostorCount")
            e.putBoolean("alwaysImpostor", value.alwaysImpostor)
            e.putBoolean("noMeetings", value.noMeetings)
            e.putBoolean("instantTasks", value.instantTasks)
            e.putBoolean("skipKillCooldown", value.skipKillCooldown)
            e.putBoolean("freeCamera", value.freeCamera)
            e.putBoolean("unlockSkins", value.unlockSkins)
            e.putBoolean("ghostMode", value.ghostMode)
            e.putBoolean("revealRoles", value.revealRoles)
            e.putBoolean("noVoteCooldown", value.noVoteCooldown)
            e.putBoolean("playerEsp", value.playerEsp)
            e.putFloat("speed", value.walkSpeedMultiplier)
            e.putInt("impostorCount", value.impostorCount)
            e.apply()
            notify("cheats", GameEngine.flagsFromCheats(value))
        }

    fun isOn(key: String): Boolean = when (key) {
        "alwaysImpostor" -> cheats.alwaysImpostor
        "noMeetings" -> cheats.noMeetings
        "instantTasks" -> cheats.instantTasks
        "skipKillCooldown" -> cheats.skipKillCooldown
        "freeCamera" -> cheats.freeCamera
        "unlockSkins" -> cheats.unlockSkins
        "ghostMode" -> cheats.ghostMode
        "revealRoles" -> cheats.revealRoles
        "noVoteCooldown" -> cheats.noVoteCooldown
        "playerEsp" -> cheats.playerEsp
        "speed" -> cheats.walkSpeedMultiplier > 1.01f
        "impostorCount" -> cheats.impostorCount > 1
        else -> false
    }

    /** Hile anahtarını değiştirir (yüzer menü ve tam ekran menü aynı yolu kullanır). */
    fun toggle(key: String, on: Boolean) {
        val e = prefs.edit()
        when (key) {
            "speed" -> e.putFloat("speed", if (on) 2f else 1f)
            "impostorCount" -> e.putInt("impostorCount", if (on) 2 else 1)
            else -> e.putBoolean(key, on)
        }
        e.apply()
        notify(key, if (on) "1" else "0")
    }

    fun setSpeed(value: Float) {
        prefs.edit().putFloat("speed", value.coerceIn(1f, 4f)).apply()
        notify("speed", value.coerceIn(1f, 4f).toString())
    }

    fun setImpostorCount(value: Int) {
        prefs.edit().putInt("impostorCount", value.coerceIn(1, 4)).apply()
        notify("impostorCount", value.coerceIn(1, 4).toString())
    }

    fun speed(): Float = prefs.getFloat("speed", 1f)
    fun impostorCount(): Int = prefs.getInt("impostorCount", 1)

    // ---------------------------------------------------------------- diğer ayarlar

    var overlayEnabled: Boolean
        get() = prefs.getBoolean("overlayEnabled", false)
        set(value) = prefs.edit().putBoolean("overlayEnabled", value).apply()

    var autoTaskEnabled: Boolean
        get() = prefs.getBoolean("autoTask", false)
        set(value) = prefs.edit().putBoolean("autoTask", value).apply()

    var autoReportEnabled: Boolean
        get() = prefs.getBoolean("autoReport", false)
        set(value) = prefs.edit().putBoolean("autoReport", value).apply()

    var playerName: String
        get() = prefs.getString("playerName", "") ?: ""
        set(value) = prefs.edit().putString("playerName", value).apply()

    var serverHost: String
        get() = prefs.getString("serverHost", "") ?: ""
        set(value) = prefs.edit().putString("serverHost", value).apply()

    var serverPort: Int
        get() = prefs.getInt("serverPort", 8080)
        set(value) = prefs.edit().putInt("serverPort", value).apply()

    var roomCode: String
        get() = prefs.getString("roomCode", "") ?: ""
        set(value) = prefs.edit().putString("roomCode", value).apply()
}
