package com.amongushile.game.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.amongushile.game.data.HileDurumu

/**
 * Gerçek Among Us üzerinde çalışan otomasyon (root gerektirmez).
 *
 * - "Otomatik Görev": görev ekranındaki onay/başla düğmelerine dokunur.
 * - "Otomatik Bildir": "Report / Bildir" düğmesine dokunur.
 *
 * Erişilebilirlik servisi kullanıcı tarafından açılmalıdır (Ayarlar > Erişilebilirlik).
 */
class AmongUsAutoService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastClickAt = 0L
    private var lastSwipeAt = 0L
    private var lastPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        HileDurumu.init(applicationContext)
        val pkg = event?.packageName?.toString() ?: return
        if (!pkg.contains("amongus") && !pkg.contains("innersloth")) return
        lastPackage = pkg

        val root = rootInActiveWindow ?: return

        if (HileDurumu.autoReportEnabled) {
            clickIfFound(root, REPORT_KEYS)
        }
        if (HileDurumu.autoTaskEnabled) {
            clickIfFound(root, USE_KEYS)
            clickIfFound(root, CONFIRM_KEYS)
            maybeSwipeCard()
        }
    }

    private fun clickIfFound(root: AccessibilityNodeInfo, keys: List<String>) {
        val now = System.currentTimeMillis()
        if (now - lastClickAt < 900) return
        val node = findNode(root, keys) ?: return
        if (node.isClickable || node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            lastClickAt = now
        }
    }

    private fun findNode(root: AccessibilityNodeInfo, keys: List<String>): AccessibilityNodeInfo? {
        if (root == null) return null
        val text = (root.text?.toString() ?: "") + "|" + (root.contentDescription?.toString() ?: "")
        val lower = text.lowercase()
        if (keys.any { lower.contains(it) }) return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found = findNode(child, keys)
            if (found != null) return found
        }
        return null
    }

    /** Kart okuma görevi için ekranı yukarı kaydırır. */
    private fun maybeSwipeCard() {
        val now = System.currentTimeMillis()
        if (now - lastSwipeAt < 3500) return
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels.toFloat()
        val h = metrics.heightPixels.toFloat()
        val path = Path().apply {
            moveTo(w * 0.5f, h * 0.78f)
            lineTo(w * 0.5f, h * 0.34f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350))
            .build()
        lastSwipeAt = now
        try {
            dispatchGesture(gesture, null, null)
        } catch (ignored: Exception) {
        }
    }

    companion object {
        @Volatile
        var instance: AmongUsAutoService? = null

        private val REPORT_KEYS = listOf("report", "rapor", "bildir", "body")
        private val USE_KEYS = listOf("use", "kullan", "interact")
        private val CONFIRM_KEYS = listOf("confirm", "submit", "done", "onayla", "tamam", "veri")
    }
}
